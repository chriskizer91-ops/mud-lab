#!/bin/bash
# build_all.sh <engine page> [out dir]
# Rebuilds the four Salt & Sand pages from the untouched engine page, one patch step each, and checks every page
# against the fingerprint of the one Christopher was sent (SHA256SUMS).
#   <engine page>  Mud Lab's base/engine-salt-and-sand.html (the same file as the original salt-and-sand.html)
#   [out dir]      where the pages go (default: ./rebuilt). The pages in pages/ are never written over.
# Needs python3 only. Exact text swaps: a changed engine page stops the step with the swap that no longer fits.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ENGINE="${1:?give the engine page, e.g. ../base/engine-salt-and-sand.html}"
OUT="${2:-$HERE/rebuilt}"
mkdir -p "$OUT"
python3 -I "$HERE/chain/patch.py"  "$ENGINE"                              "$OUT/salt-and-sand-lean.html"
python3 -I "$HERE/chain/patch2.py" "$OUT/salt-and-sand-lean.html"         "$OUT/salt-and-sand-showroom.html"
python3 -I "$HERE/chain/patch3.py" "$OUT/salt-and-sand-showroom.html"     "$OUT/salt-and-sand-showroom-2.html"
python3 -I "$HERE/chain/patch4.py" "$OUT/salt-and-sand-showroom-2.html"   "$OUT/salt-and-sand-showroom-3.html"
echo "--- fingerprints (each must say OK)"
fail=0
for f in salt-and-sand-lean.html salt-and-sand-showroom.html salt-and-sand-showroom-2.html salt-and-sand-showroom-3.html; do
  want="$(grep "  pages/$f\$" "$HERE/SHA256SUMS" | cut -d' ' -f1)"
  got="$(sha256sum "$OUT/$f" | cut -d' ' -f1)"
  if [ "$want" = "$got" ]; then echo "OK    $f"; else echo "DIFF  $f"; fail=1; fi
done
exit $fail
