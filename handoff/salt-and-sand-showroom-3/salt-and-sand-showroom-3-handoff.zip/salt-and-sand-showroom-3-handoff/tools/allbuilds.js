/* every Studio 2 build through the page's own worker code (kit + maker as built): does it build, how big is it lean, are the colours inside what 16 bits hold */
const L=require('./kitrun.js').load('/home/claude/build/kit_built.js','/home/claude/build/src/s2make.js');
const K0=require('./kitrun.js').load();   // the page as sent: for the colour range of the raw pieces
for(const key of ['stock','sleeper','crawler','race','coupe','coupeGT','hatch','hatchB','wedge','wedgeNR']){
  const m=L.make(key);let nt=0,nv=0,vb=0,ib=0;const P=m.pieces;
  for(const [n,d] of Object.entries(P)){const x=n==='wheelL'?2:n==='wheel'&&P.wheelL?2:/^(wheel|brake)$/.test(n)?(P[n+'R']?2:4):/^(wheel|brake)R$/.test(n)?2:1;nt+=d.nt*x;nv+=d.nu*x;vb+=d.vtx.byteLength;ib+=d.idx.byteLength;}
  const r=K0.make(key);let cmax=0,emax=-9,emin=9,raw=0,soup=0;for(const [n,d] of Object.entries(r.pieces)){raw+=d.pos.byteLength+d.nrm.byteLength+d.col.byteLength+d.mat.byteLength;const x=/^(wheel|brake)$/.test(n)?(r.pieces[n+'R']?2:4):/^(wheel|brake)R$/.test(n)?2:1;soup+=d.mat.length*x;for(let i=0;i<d.col.length;i+=4){cmax=Math.max(cmax,d.col[i],d.col[i+1],d.col[i+2]);emax=Math.max(emax,d.col[i+3]);emin=Math.min(emin,d.col[i+3]);}}
  console.log(key.padEnd(8),'triangles',String(nt).padStart(7),'corners a frame',String(soup).padStart(8),'->',String(nv).padStart(7),'memory MB',(raw/1048576).toFixed(1).padStart(5),'->',((vb+ib)/1048576).toFixed(1).padStart(5),'colour max',cmax.toFixed(2),'glow',emin.toFixed(2),emax.toFixed(2),Object.keys(P).includes('wheelL')?'wheelL':'');}
