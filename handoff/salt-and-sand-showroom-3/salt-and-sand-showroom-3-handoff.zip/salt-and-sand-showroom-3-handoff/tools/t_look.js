/* close looks at a build in the bay and on the road, at a chosen tier. usage: node t_look.js <page> <outdir> <key> [Q] */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3],key=process.argv[4]||'stock';require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,shot,errs,T,pick}=await H.boot(page,{W:+(process.env.W||1280),H:+(process.env.H||720),Q:process.argv[5]||'high'});
  if(key!=='stock')await pick(key);
  console.log('booted',T(),JSON.stringify(await ev('return TT.s2()')));
  const N=+(process.env.FR||10);
  await shot(out+'/bay_front34.png',"Y.SHOW.hood=false;Y.SHOW.hoodA=0;TT.view('front34');return TT.s2();",N);
  await shot(out+'/bay_side.png',"TT.view('side');",N);
  await shot(out+'/bay_rear34.png',"TT.view('rear34');",N);
  await shot(out+'/bay_wheel.png',"TT.cam({th:-25,ph:4,d:1.7,ty:.5,ox:1.4,oy:-.2,oz:.9});",N);
  await shot(out+'/bay_face.png',"TT.cam({th:-70,ph:6,d:2.6,ty:.8,ox:1.2,oy:0,oz:0});",N);
  await shot(out+'/bay_under.png',"TT.view('under');",N);
  await shot(out+'/bay_engine.png',"Y.SHOW.hood=true;Y.SHOW.hoodA=1;TT.view('bay');",N);
  await shot(out+'/bay_cabin.png',"Y.SHOW.hood=false;Y.SHOW.hoodA=0;TT.cam({th:-150,ph:14,d:2.4,ty:1.1,ox:-.3,oy:.2,oz:0});",N);
  console.log(errs.filter(e=>!/ReadPixels/.test(e)).length?'page errors:\n  '+[...new Set(errs)].slice(0,14).join('\n  '):'no page errors');await b.close();})();
