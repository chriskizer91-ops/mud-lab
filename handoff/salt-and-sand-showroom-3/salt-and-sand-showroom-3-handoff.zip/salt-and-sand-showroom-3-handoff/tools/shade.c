/* shade.c: a quick software picture of lean pieces (28-byte corners + indices), to judge the lighter copies fast.
   Smooth normals, the paint glossy under a striped sky (stripes show any kink in a surface), plain light on the rest.
   usage: shade out.ppm W H ex ey ez tx ty tz fovdeg  piece.vtx piece.idx [tx ty tz sz] ...   (idx: u32; optional per-piece move+mirror) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <stdint.h>
typedef struct{float p[3];int16_t n[3];int16_t mat;int16_t c[4];} __attribute__((packed)) Vtx;
static void* rdfile(const char*p,long*sz){FILE*f=fopen(p,"rb");if(!f){fprintf(stderr,"no %s\n",p);exit(1);}fseek(f,0,SEEK_END);*sz=ftell(f);fseek(f,0,SEEK_SET);void*d=malloc(*sz);if(fread(d,1,*sz,f)!=(size_t)*sz){}fclose(f);return d;}
static void nrm(double*v){double l=sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);if(l>0){v[0]/=l;v[1]/=l;v[2]/=l;}}
static void crs(const double*a,const double*b,double*c){c[0]=a[1]*b[2]-a[2]*b[1];c[1]=a[2]*b[0]-a[0]*b[2];c[2]=a[0]*b[1]-a[1]*b[0];}
static void sky(const double*d,double*c){ /* stripes by elevation, a soft horizon, ground below */
  double e=asin(fmax(-1,fmin(1,d[1])))*57.29578; if(e<0){c[0]=.62;c[1]=.6;c[2]=.55;return;}
  double s=0.5+0.5*sin(e*0.9+atan2(d[2],d[0])*2.0); s=s>0.5?1:0.25; double t=e/90; c[0]=(0.9-0.6*t)*s+.05;c[1]=(0.92-0.45*t)*s+.05;c[2]=(1.0-0.25*t)*s+.05;}
int main(int argc,char**argv){
  const char*out=argv[1];int W=atoi(argv[2]),H=atoi(argv[3]),SS=2;double eye[3]={atof(argv[4]),atof(argv[5]),atof(argv[6])},tg[3]={atof(argv[7]),atof(argv[8]),atof(argv[9])},fov=atof(argv[10])*M_PI/180;
  int w=W*SS,h=H*SS;float*zb=malloc(sizeof(float)*w*h);float*img=calloc(w*h*3,sizeof(float));for(long i=0;i<(long)w*h;i++)zb[i]=FLT_MAX;
  double f[3]={tg[0]-eye[0],tg[1]-eye[1],tg[2]-eye[2]};nrm(f);double up[3]={0,1,0},r[3],u[3];crs(f,up,r);nrm(r);crs(r,f,u);double foc=h*0.5/tan(fov/2);
  double L[3]={0.35,0.82,0.45};nrm(L);long tot=0;
  for(int a=11;a<argc;){const char*vp=argv[a++],*ip=argv[a++];double T[3]={0,0,0},sz=1;if(a+3<argc&&strstr(argv[a],".vtx")==NULL&&(argv[a][0]=='-'||(argv[a][0]>='0'&&argv[a][0]<='9')||argv[a][0]=='.')){T[0]=atof(argv[a]);T[1]=atof(argv[a+1]);T[2]=atof(argv[a+2]);sz=atof(argv[a+3]);a+=4;}
    long vs,is;Vtx*V=rdfile(vp,&vs);uint32_t*I=rdfile(ip,&is);long nt=is/12;tot+=nt;
    for(long t=0;t<nt;t++){double X[3],Y[3],Z[3],N[3][3],C[3][3];int mat=0,ok=1;
      for(int j=0;j<3;j++){const Vtx*v=&V[I[t*3+j]];double p[3]={v->p[0]+T[0],v->p[1]+T[1],v->p[2]*sz+T[2]};double d[3]={p[0]-eye[0],p[1]-eye[1],p[2]-eye[2]};
        double x=d[0]*r[0]+d[1]*r[1]+d[2]*r[2],y=d[0]*u[0]+d[1]*u[1]+d[2]*u[2],z=d[0]*f[0]+d[1]*f[1]+d[2]*f[2];if(z<0.05){ok=0;break;}
        X[j]=w*0.5+x/z*foc;Y[j]=h*0.5-y/z*foc;Z[j]=z;N[j][0]=v->n[0]/32767.0;N[j][1]=v->n[1]/32767.0;N[j][2]=v->n[2]/32767.0*sz;C[j][0]=v->c[0]/32767.0;C[j][1]=v->c[1]/32767.0;C[j][2]=v->c[2]/32767.0;mat=v->mat;}
      if(!ok)continue;
      int x0=(int)floor(fmin(X[0],fmin(X[1],X[2]))),x1=(int)ceil(fmax(X[0],fmax(X[1],X[2]))),y0=(int)floor(fmin(Y[0],fmin(Y[1],Y[2]))),y1=(int)ceil(fmax(Y[0],fmax(Y[1],Y[2])));
      if(x0<0)x0=0;if(y0<0)y0=0;if(x1>w-1)x1=w-1;if(y1>h-1)y1=h-1;if(x0>x1||y0>y1)continue;
      double A=(X[1]-X[0])*(Y[2]-Y[0])-(X[2]-X[0])*(Y[1]-Y[0]);if(fabs(A)<1e-12)continue;double iA=1/A;
      for(int py=y0;py<=y1;py++)for(int px=x0;px<=x1;px++){double cx=px+.5,cy=py+.5;
        double w0=((X[1]-cx)*(Y[2]-cy)-(X[2]-cx)*(Y[1]-cy))*iA,w1=((X[2]-cx)*(Y[0]-cy)-(X[0]-cx)*(Y[2]-cy))*iA,w2=1-w0-w1;if(w0<0||w1<0||w2<0)continue;
        /* perspective-correct weights */
        double q0=w0/Z[0],q1=w1/Z[1],q2=w2/Z[2],qs=q0+q1+q2;float z=(float)(1/qs);long o=(long)py*w+px;if(z>=zb[o])continue;zb[o]=z;q0/=qs;q1/=qs;q2/=qs;
        double n[3]={N[0][0]*q0+N[1][0]*q1+N[2][0]*q2,N[0][1]*q0+N[1][1]*q1+N[2][1]*q2,N[0][2]*q0+N[1][2]*q1+N[2][2]*q2};nrm(n);
        double vd[3]={(cx-w*.5)/foc,-(cy-h*.5)/foc,1};double V3[3]={-(vd[0]*r[0]+vd[1]*u[0]+vd[2]*f[0]),-(vd[0]*r[1]+vd[1]*u[1]+vd[2]*f[1]),-(vd[0]*r[2]+vd[1]*u[2]+vd[2]*f[2])};nrm(V3);
        double nv=n[0]*V3[0]+n[1]*V3[1]+n[2]*V3[2];if(nv<0){n[0]=-n[0];n[1]=-n[1];n[2]=-n[2];nv=-nv;}
        double alb[3]={C[0][0]*q0+C[1][0]*q1+C[2][0]*q2,C[0][1]*q0+C[1][1]*q1+C[2][1]*q2,C[0][2]*q0+C[1][2]*q1+C[2][2]*q2};double gloss=0.05;
        if(mat==1||mat==4){alb[0]=.30;alb[1]=.22;alb[2]=.15;gloss=.55;}else if(mat==2||mat==3||mat==70||mat==91){alb[0]=alb[1]=alb[2]=.03;gloss=.8;}else if(mat==5||mat==79||mat==90||mat==81){gloss=.9;alb[0]=alb[1]=alb[2]=.3;}
        double nl=fmax(0,n[0]*L[0]+n[1]*L[1]+n[2]*L[2]),amb=0.35+0.25*n[1];
        double R[3]={2*nv*n[0]-V3[0],2*nv*n[1]-V3[1],2*nv*n[2]-V3[2]},sc[3];sky(R,sc);double fr=gloss*(0.08+0.92*pow(1-nv,5));
        for(int k=0;k<3;k++)img[o*3+k]=(float)(alb[k]*(amb+1.6*nl)*(1-fr)+sc[k]*fr*1.2);}
    }
    free(V);free(I);}
  FILE*fo=fopen(out,"wb");fprintf(fo,"P6\n%d %d\n255\n",W,H);
  for(int y=0;y<H;y++)for(int x=0;x<W;x++){double c[3]={0,0,0};for(int sy=0;sy<SS;sy++)for(int sx=0;sx<SS;sx++){long o=(long)(y*SS+sy)*w+(x*SS+sx);if(zb[o]==FLT_MAX){c[0]+=.75;c[1]+=.78;c[2]+=.82;}else for(int k=0;k<3;k++)c[k]+=img[o*3+k];}
    unsigned char px[3];for(int k=0;k<3;k++){double v=c[k]/(SS*SS);v=v/(1+v*0.35);v=pow(fmax(0,v),1/2.2);px[k]=(unsigned char)(fmin(1,v)*255+.5);}fwrite(px,1,3,fo);}
  fclose(fo);fprintf(stderr,"%ld triangles\n",tot);return 0;}
