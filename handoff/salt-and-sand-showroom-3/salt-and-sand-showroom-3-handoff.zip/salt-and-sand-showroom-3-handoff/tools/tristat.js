const fs=require('fs');const dir=process.argv[2];
for(const n of ['body','bodyG','hood','liner','engine','wheel','brake']){let b;try{b=fs.readFileSync(`${dir}/${n}.pos.f32`);}catch(e){continue;}
  const P=new Float32Array(b.buffer,b.byteOffset,b.length/4),nt=P.length/9;let c2=0,c5=0,c10=0,area=0,probes=0,probes4=0;const h=[0,0,0,0,0,0,0];
  for(let t=0;t<nt;t++){const o=t*9,e=(a,b)=>Math.hypot(P[o+a*3]-P[o+b*3],P[o+a*3+1]-P[o+b*3+1],P[o+a*3+2]-P[o+b*3+2]);const l=Math.max(e(0,1),e(1,2),e(2,0));
    const ux=P[o+3]-P[o],uy=P[o+4]-P[o+1],uz=P[o+5]-P[o+2],vx=P[o+6]-P[o],vy=P[o+7]-P[o+1],vz=P[o+8]-P[o+2];const A=.5*Math.hypot(uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx);area+=A;
    if(l>.02)c2++;if(l>.05)c5++;if(l>.1)c10++;h[Math.min(6,Math.max(0,Math.floor(Math.log2(l*1000))-1))]++;
    const k=Math.min(12,Math.ceil(l/.025));probes+=l>.02?(k+1)*(k+2)/2:0;const k4=Math.min(10,Math.ceil(l/.04));probes4+=l>.03?(k4+1)*(k4+2)/2:0;}
  console.log(n.padEnd(7),'tris',nt,'area m2',area.toFixed(1),'>2cm',c2,'>5cm',c5,'>10cm',c10,'grid probes@2.5cm',probes,'@4cm',probes4,'edge mm hist [<4,<8,<16,<32,<64,<128,more]',h.join(' '));}
