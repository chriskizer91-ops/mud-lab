#!/bin/bash
# shot3.sh <dir> <name> W H ex ey ez tx ty tz fov : the body+hood+glass+wheels as full | copy 1 | copy 2, side by side
d=$1; n=$2; shift 2; S=/home/claude/tools/shade
fx=1.53; wb=2.89; R=0.378; tw=0.8
if [ -f $d/info.json ]; then read fx wb R tw < <(python3 -I -c "import json,sys;i=json.load(open('$d/info.json'));print(i['fx'],i['wb'],i['R'],i['tw'])"); fi
rx=$(python3 -I -c "print($fx-$wb)")
for v in u l1 l2; do
  b=$d/body.$v.idx; [ -f $b ] || b=$d/body.idx
  w=$d/wheel.$v.idx; [ -f $w ] || w=$d/wheel.idx
  h=$d/hood.$v.idx; [ -f $h ] || h=$d/hood.idx
  g=$d/bodyG.$v.idx; [ -f $g ] || g=$d/bodyG.idx
  $S /tmp/$n.$v.ppm "$@" $d/body.vtx $b $d/hood.vtx $h $d/bodyG.vtx $g $d/wheel.vtx $w $fx $R $tw 1 $d/wheel.vtx $w $fx $R -$tw -1 $d/wheel.vtx $w $rx $R $tw 1 $d/wheel.vtx $w $rx $R -$tw -1 2>&1 | tr '\n' ' '
done; echo
python3 -I -c "
from PIL import Image
ims=[Image.open('/tmp/$n.%s.ppm'%v) for v in ['u','l1','l2']];w,h=ims[0].size
o=Image.new('RGB',(w*3+20,h),(20,20,20))
for i,x in enumerate(ims):o.paste(x,(i*(w+10),0))
o.save('$d/$n.png')"
