/* the same drive on two pages: the numbers must match to the last digit (the physics is untouched).
   usage: node t_phys.js <page> [key] [query] */
const H=require('./base.js');
(async()=>{const page=process.argv[2],key=process.argv[3]||'stock',query=process.argv[4]||'';
  const {b,p,ev,errs,T,pick,bake}=await H.boot(page,{W:640,H:360,Q:'mobile',query});
  if(key!=='stock')await pick(key);
  const L=[];const run=async(name,code)=>{const r=await ev(code);delete r.tris;delete r.draws;L.push(name+' '+JSON.stringify(r));};
  await ev("document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;return 0;");
  await run('road 7 s flat out',"TT.place(300,1.9,0);TT.drive(1,{thr:0},0);return TT.drive(7,{thr:1},0);");
  await run('road brake 3 s',"return TT.drive(3,{brk:1},0);");
  await run('road turn 4 s',"TT.place(300,1.9,0);TT.drive(1,{thr:0},0);TT.drive(3,{thr:1},0);return TT.drive(4,{thr:.5,steer:.5},0);");
  await run('sand 6 s',"TT.place(420,170,0);TT.drive(1.5,{thr:0},0);return TT.drive(6,{thr:.9},0);");
  await run('dune jump 5 s',"return TT.drive(5,{thr:1},0);");
  await run('salt 8 s',"TT.place(800,-150,0);TT.drive(1,{thr:0},0);return TT.drive(8,{thr:1,steer:-.1},0);");
  console.log(L.join('\n'));const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors: '+[...new Set(e2)].slice(0,5).join(' | '):'no page errors');await b.close();})();
