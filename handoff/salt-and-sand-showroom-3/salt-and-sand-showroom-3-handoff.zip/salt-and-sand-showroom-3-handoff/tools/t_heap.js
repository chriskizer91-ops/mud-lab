/* what makes garbage in a frame: Chrome's own allocation sampler over 60 frames of driving, by function. usage: node t_heap.js <page> [query] */
const H=require('./base.js');
(async()=>{const page=process.argv[2],query=process.argv[3]||'';
  const {b,p,ev,errs,T,bake}=await H.boot(page,{W:960,H:540,Q:'mobile',query});
  await bake();
  await ev("document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;TT.place(300,1.9,0);TT.drive(3,{thr:1},6);return 0;");
  const cdp=await p.context().newCDPSession(p);
  const sample=async(name,code,n)=>{await cdp.send('HeapProfiler.enable');await cdp.send('HeapProfiler.collectGarbage');await cdp.send('HeapProfiler.startSampling',{samplingInterval:2048,includeObjectsCollectedByMajorGC:true,includeObjectsCollectedByMinorGC:true});
    await ev(code,n);const {profile}=await cdp.send('HeapProfiler.stopSampling');
    const agg=new Map();let tot=0;const walk=nd=>{const f=nd.callFrame,k=(f.functionName||'(anonymous)')+' @'+(f.lineNumber+1)+':'+f.columnNumber;if(nd.selfSize){agg.set(k,(agg.get(k)||0)+nd.selfSize);tot+=nd.selfSize;}for(const c of nd.children||[])walk(c);};walk(profile.head);
    console.log(`\n${name}: about ${(tot/n/1024).toFixed(0)} KB a frame`);for(const [k,v] of [...agg.entries()].sort((a,b)=>b[1]-a[1]).slice(0,14))console.log('  '+(v/n/1024).toFixed(1).padStart(8)+' KB  '+k);};
  await sample('a whole frame (step + draw)',"Y.setTestInput({steer:.1,thr:1,brk:0,hb:0,nos:false});for(let i=0;i<arg;i++){Y.APP.t+=1/60;Y.step(1/60);Y.render(1/60);}return 0;",40);
  await sample('the physics alone',"for(let i=0;i<arg;i++){Y.APP.t+=1/60;Y.step(1/60);}return 0;",600);
  await b.close();})();
