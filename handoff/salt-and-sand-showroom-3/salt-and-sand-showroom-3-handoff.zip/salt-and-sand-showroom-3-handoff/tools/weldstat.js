const K=require('./kitrun.js').load();
for(const key of (process.argv[2]||'stock').split(',')){const m=K.make(key);
  let TV=0,TU=0,TP=0;
  for(const [n,d] of Object.entries(m.pieces)){const nv=d.pos.length/3;
    const f=new Float32Array(11),u8=new Uint8Array(f.buffer),u32=new Uint32Array(f.buffer);
    const M=new Map(),MP=new Map();let uq=0,up=0;
    for(let i=0;i<nv;i++){f[0]=d.pos[i*3];f[1]=d.pos[i*3+1];f[2]=d.pos[i*3+2];f[3]=d.nrm[i*3];f[4]=d.nrm[i*3+1];f[5]=d.nrm[i*3+2];f[6]=d.col[i*4];f[7]=d.col[i*4+1];f[8]=d.col[i*4+2];f[9]=d.col[i*4+3];f[10]=d.mat[i];
      let k='';for(let j=0;j<11;j++)k+=u32[j].toString(36)+',';if(!M.has(k)){M.set(k,uq++);}
      const kp=u32[0].toString(36)+','+u32[1].toString(36)+','+u32[2].toString(36);if(!MP.has(kp))MP.set(kp,up++);}
    let cmax=0,cmin=1e9,emax=-1e9,emin=1e9;for(let i=0;i<nv;i++){for(let j=0;j<3;j++){const c=d.col[i*4+j];if(c>cmax)cmax=c;if(c<cmin)cmin=c;}const e=d.col[i*4+3];if(e>emax)emax=e;if(e<emin)emin=e;}
    let b0=[1e9,1e9,1e9],b1=[-1e9,-1e9,-1e9];for(let i=0;i<nv;i++)for(let j=0;j<3;j++){const v=d.pos[i*3+j];if(v<b0[j])b0[j]=v;if(v>b1[j])b1[j]=v;}
    const mult=/^(wheel|brake)$/.test(n)?4:1;TV+=nv*mult;TU+=uq*mult;TP+=up*mult;
    console.log(key,n.padEnd(7),'tris',String(nv/3).padStart(7),'verts',String(nv).padStart(8),'unique',String(uq).padStart(7),(uq/(nv/3)).toFixed(2)+'/tri','posOnly',String(up).padStart(7),(up/(nv/3)).toFixed(2)+'/tri','col',cmin.toFixed(2),cmax.toFixed(2),'em',emin.toFixed(2),emax.toFixed(2),'bbox',b0.map(v=>v.toFixed(2)).join(' '),'|',b1.map(v=>v.toFixed(2)).join(' '));
  }
  console.log(key,'TOTAL drawn verts',TV,'unique',TU,'posOnly',TP);
}
