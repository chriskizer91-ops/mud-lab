#!/bin/bash
# waits for the long check to finish, then the physics comparison and the JavaScript timing, one after another
while pgrep -f t_final.js >/dev/null; do sleep 10; done
O=/home/claude/out/final; cd /home/claude/tools
for k in stock crawler; do
  node t_phys.js /home/claude/work/orig/salt-and-sand.html $k > $O/phys_orig_$k.log 2>&1
  node t_phys.js $O/page.html $k "s2bake=8" > $O/phys_new_$k.log 2>&1
done
node t_prof.js /home/claude/work/orig/salt-and-sand.html > $O/prof_orig.log 2>&1
node t_prof.js $O/page.html "s2bake=8" > $O/prof_new.log 2>&1
echo done > $O/after.done
