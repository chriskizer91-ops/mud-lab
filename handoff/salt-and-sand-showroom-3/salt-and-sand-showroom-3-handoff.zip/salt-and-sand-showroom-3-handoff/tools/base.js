/* Shared test harness: boots a Salt & Sand page in headless Chrome (software GL), holds its loop, and gives helpers.
   usage: const H=require('./base.js'); const {b,p,shot,ev}=await H.boot(pagePath,{W,H,Q,touch}); */
const {chromium}=require('/opt/npm-tools/node_modules/playwright');const fs=require('fs'),path=require('path');
exports.boot=async function(pagePath,o={}){
  const W=o.W||960,Hh=o.H||540;
  const args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required','--js-flags=--expose-gc','--enable-precise-memory-info'];
  const b=await chromium.launch({executablePath:'/usr/bin/google-chrome',args});
  const p=await b.newPage(Object.assign({viewport:{width:W,height:Hh},deviceScaleFactor:1},o.touch?{hasTouch:true,isMobile:true}:{}));
  const errs=[];p.on('pageerror',e=>errs.push('pageerror: '+e.message));p.on('console',m=>{if(m.type()==='error'||m.type()==='warning')errs.push(m.type()+': '+m.text().slice(0,400));if(o.log&&m.type()==='log')console.log('  [page]',m.text().slice(0,400));});
  const t0=Date.now(),T=()=>((Date.now()-t0)/1000).toFixed(0)+'s';
  await p.goto('file://'+path.resolve(pagePath)+'?quality='+(o.Q||'mobile')+(o.query?'&'+o.query:'')+(o.hash||''));
  await p.waitForFunction(()=>window.__dyb&&document.getElementById('loading').hidden&&window.__dyb.DYB.S2.size>0,null,{timeout:900000,polling:500});
  await p.evaluate(()=>{const Y=window.__dyb;Y.GAME.hold=true;
    window.TT={
      drive(sec,inp,every=12){Y.setTestInput(Object.assign({steer:0,thr:0,brk:0,hb:0,nos:false},inp));const n=Math.round(sec*60);
        TT.air=0;for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);if(Y.GAME.car.wheels.every(w=>!w.contact))TT.air++;if(every&&i%every===every-1)Y.render(1/60);}TT.air=+(TT.air/60).toFixed(2);return TT.info();},
      draw(n){for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);Y.render(1/60);}},
      drawOnly(n){for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.render(1/60);}},
      info(){const t=Y.GAME.car,pt=t.pt;return {mph:+(t.speed*2.237).toFixed(2),gear:pt.gear,rpm:Math.round((pt.we||0)*60/6.2832),x:+t.p[0].toFixed(2),y:+t.p[1].toFixed(3),z:+t.p[2].toFixed(2),
        surf:t.wheels.map(w=>w.contact?w.surf:'air').join(','),air:TT.air,tris:Y.APP.tris,draws:Y.GLC.n,state:Y.GAME.state};},
      place(x,z,yaw){Y.placeCar(x,z,yaw);Y.CAM.cut=true;Y.WORLD.rush=Y.APP.t+4;},
      view(v){Y.showSetView(v);Y.SHOW.cam=null;Y.SHOW.yaw=0;},
      cam(o){Y.SHOW.camT=Object.assign({th:-30,ph:10,d:7,ty:.8},o);Y.SHOW.view=null;Y.SHOW.cam=null;},
      s2(){const k=Y.s2Key(Y.APP.bi),S=Y.DYB.S2.get(k);return S?{k,tris:S.tris,draws:S.draws,ms:S.ms}:{k,building:!!Y.DYB.busy,err:Y.DYB.err[k]};}};});
  const ev=(code,arg)=>p.evaluate(async([code,arg])=>{const Y=window.__dyb;return await (new Function('Y','TT','arg','return (async()=>{'+code+'})()'))(Y,window.TT,arg);},[code,arg]);
  const shot=async(file,code,n=8)=>{const r=code?await ev(code):null;if(n)await ev('TT.draw('+n+')');await p.screenshot({path:file,timeout:900000});console.log(path.basename(file),T(),r===null||r===undefined?'':JSON.stringify(r));return r;};
  const waitS2=()=>p.waitForFunction(()=>{const Y=window.__dyb,k=Y.s2Key(Y.APP.bi);Y.s2For(Y.APP.bi);return !k||Y.DYB.S2.has(k)||Y.DYB.err[k];},null,{timeout:900000,polling:300});
  const CAR={stock:'suv',sleeper:'suv',crawler:'suv',race:'suv',coupe:'coupe',coupeGT:'coupe',hatch:'hatch',hatchB:'hatch',wedge:'wedge',wedgeNR:'wedge'};
  const pick=async k=>{await p.evaluate(([car,k])=>{const Y=window.__dyb;if(Y.APP.car!==car)Y.pickCar(car);Y.RIGS[car]=Y.presetRig(k);Y.spawnRig();Y.s2For(Y.APP.bi);},[CAR[k],k]);await waitS2();};
  /* the bake of the car on screen, stepped to its end (the loop is held: each step is a few directions) */
  const bake=async()=>{for(let i=0;i<4000;i++){const r=await p.evaluate(()=>{const Y=window.__dyb;if(!Y.S2B||!Y.S2B.N)return {off:true};const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));if(!S)return null;if(S.baked)return S.baked;if(!S.bk)return {none:true};for(let k=0;k<4;k++)Y.s2BakeStep();return S.baked||null;});if(r)return r;}return {timeout:true};};
  return {b,p,ev,shot,errs,T,waitS2,pick,bake};
};
