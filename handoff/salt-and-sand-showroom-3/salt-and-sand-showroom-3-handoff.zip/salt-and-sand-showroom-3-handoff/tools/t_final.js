/* the checks with pictures, on the page as it ships (the bake at its own setting):
   the bay with the baked shade on and off; each driving camera parked, drawn as every triangle (full), as only what the
   view needs (lean), and as shipped with the lighter copies (lod), from the same frozen start each time.
   usage: node t_final.js <page> <outdir> [key] [query]   env Q W H FR CAMS BAY=0 */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3],key=process.argv[4]||'stock',query=process.argv[5]||'';require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,errs,T,pick,bake}=await H.boot(page,{W:+(process.env.W||1280),H:+(process.env.H||720),Q:process.env.Q||'medium',query});
  if(key!=='stock')await pick(key);
  console.log('booted',T(),JSON.stringify(await ev('return TT.s2()')));
  const bk=await bake();console.log('bake',T(),JSON.stringify(bk));
  const lods=await p.waitForFunction(()=>{const Y=window.__dyb,S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return !Y.S2B.lod||!Y.DYB.w||(S&&S.lods)||null;},null,{timeout:120000,polling:300}).then(h=>h.jsonValue()).catch(()=>null);
  console.log('lighter copies',T(),JSON.stringify(lods));
  const N=+(process.env.FR||7);
  const PIN="Y.R.frameN=4000;Y.R.resetTAA=true;Y.R.probeFilled=0;Y.R.probeFace=0;";
  if(process.env.BAY!=='0'){
    await ev("Y.GAME.dirt=0;return 0;");
    const bay=async(name,setup)=>{await ev(setup+"TT.drawOnly(3);return 0;");
      for(const ao of [1,0]){await ev("Y.S2B.ao=!!arg[0];"+PIN+"for(let i=0;i<arg[1];i++)Y.render(0);return 0;",[ao,N]);await p.screenshot({path:`${out}/bay_${name}_${ao?'shade':'plain'}.png`,timeout:900000});console.log('bay',name,ao?'shade':'plain',T());}
      await ev("Y.S2B.ao=true;return 0;");};
    await bay('front34',"Y.SHOW.hood=false;Y.SHOW.hoodA=0;TT.view('front34');");
    await bay('engine',"Y.SHOW.hood=true;Y.SHOW.hoodA=1;TT.view('bay');");
    await bay('wheel',"Y.SHOW.hood=false;Y.SHOW.hoodA=0;TT.cam({th:-78,ph:4,d:2.0,ty:.5,ox:1.5,oy:0,oz:.9});");
    await bay('low',"TT.view('low');");
  }
  await ev("Y.SHOW.hood=false;Y.SHOW.hoodA=0;document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;TT.place(300,1.9,0);TT.drive(2,{thr:.6},0);TT.drive(3,{hb:1},0);TT.draw(10);return TT.info();").then(r=>console.log('parked',JSON.stringify(r)));
  const names=await ev("return Y.CAMS.slice();");
  const want=(process.env.CAMS||'Chase,Far,Wheel cam,Roadside,Drone follow').split(',');
  const MODES={full:"Y.S2B.cull=false;Y.S2B.lod=false;Y.S2B.ao=true;",lean:"Y.S2B.cull=true;Y.S2B.lod=false;Y.S2B.ao=true;",lod:"Y.S2B.cull=true;Y.S2B.lod=true;Y.S2B.ao=true;",plain:"Y.S2B.cull=false;Y.S2B.lod=false;Y.S2B.ao=false;"};
  for(const nm of want){const i=names.indexOf(nm);if(i<0){console.log('no camera',nm);continue;}const f=nm.replace(/\W+/g,'_').toLowerCase();
    await ev("Y.APP.cam=arg;Y.CAM.cut=true;Y.S2B.cull=true;Y.S2B.lod=true;TT.draw(6);return 0;",i);
    for(const md of (process.env.MODES||'full,lean,lod,plain').split(',')){
      const r=await ev(MODES[md]+"const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));S.lodK=0;"+PIN+"Y.CAM.cutFrame=true;for(let i=0;i<arg;i++)Y.render(0);return {drawn:Math.round(S.drawn),shadow:Math.round(S.drawnSh),copy:S.lodK,px_mm:S.lodPx?+(S.lodPx*1000).toFixed(1):0};",N);
      await p.screenshot({path:`${out}/${f}_${md}.png`,timeout:900000});console.log(nm.padEnd(13),md.padEnd(5),JSON.stringify(r),T());}
  }
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,14).join('\n  '):'no page errors');await b.close();})();
