/* the glass's grain: the bay, side view, the picture left to settle for N frames with the old see-through and the new.
   usage: node t_glass.js <page> <outdir> [frames=36] */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3],N=+(process.argv[4]||36);require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,errs,T}=await H.boot(page,{W:960,H:540,Q:'medium',query:'s2bake=0'});
  await ev("Y.GAME.dirt=0;Y.SHOW.hood=false;Y.SHOW.hoodA=0;Y.SHOW.spin=false;Y.SHOW.stage='dark';TT.view('side');TT.drawOnly(4);return 0;");
  for(const g of [0,1]){await ev("Y.LOOK.glass=arg[0];Y.R.resetTAA=true;TT.drawOnly(arg[1]);return 0;",[g,N]);await p.screenshot({path:`${out}/glass_${g?'new':'old'}.png`,timeout:900000});console.log('glass',g?'new':'old',T());}
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,10).join('\n  '):'no page errors');await b.close();})().catch(e=>{console.error('FAILED',e.message.slice(0,600));process.exit(1);});
