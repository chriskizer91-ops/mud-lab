#!/usr/bin/env python3
"""sheet.py out.png "title" img1 "label1" [x0,y0,x1,y1] img2 "label2" [box] ... --cols N --scale K : crops side by side with a label under each"""
import sys
from PIL import Image, ImageDraw, ImageFont
a=sys.argv[1:];out=a.pop(0);title=a.pop(0);cols=2;scale=1.0;items=[]
while a:
    x=a.pop(0)
    if x=='--cols':cols=int(a.pop(0));continue
    if x=='--scale':scale=float(a.pop(0));continue
    lab=a.pop(0);box=None
    if a and a[0].count(',')==3 and a[0][0].isdigit():box=tuple(int(v) for v in a.pop(0).split(','))
    items.append((x,lab,box))
def font(sz):
    for p in ['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf','/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf']:
        try:return ImageFont.truetype(p,sz)
        except Exception:pass
    return ImageFont.load_default()
F=font(22);FT=font(28);ims=[]
for p,lab,box in items:
    im=Image.open(p).convert('RGB')
    if box:im=im.crop(box)
    if scale!=1:im=im.resize((int(im.size[0]*scale),int(im.size[1]*scale)),Image.LANCZOS)
    ims.append((im,lab))
w=max(i.size[0] for i,_ in ims);h=max(i.size[1] for i,_ in ims);rows=(len(ims)+cols-1)//cols;pad=14;lh=40;th=56
o=Image.new('RGB',(cols*w+(cols+1)*pad,th+rows*(h+lh+pad)+pad),(18,18,22));d=ImageDraw.Draw(o);d.text((pad,14),title,fill=(255,200,90),font=FT)
for k,(im,lab) in enumerate(ims):
    x=pad+(k%cols)*(w+pad);y=th+(k//cols)*(h+lh+pad);o.paste(im,(x,y));d.text((x+4,y+h+7),lab,fill=(235,235,240),font=F)
o.save(out);print(out,o.size)
