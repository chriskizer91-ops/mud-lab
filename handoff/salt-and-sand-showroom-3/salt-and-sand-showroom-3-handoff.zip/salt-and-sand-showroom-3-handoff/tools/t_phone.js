/* a phone held sideways (915 x 412, touch): boot into the bay, the bake, Drive, the Dev look switches. usage: node t_phone.js <page> <outdir> [query] */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3],query=process.argv[4]||'';require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,errs,T,bake}=await H.boot(page,{W:915,H:412,Q:'mobile',touch:true,query});
  console.log('booted',T(),JSON.stringify(await ev('return Object.assign(TT.s2(),{touchy:matchMedia("(hover: none)").matches,H:Y.R.H,W:Y.R.W,scale:+Y.R.scale.toFixed(2)})')));
  const bk=await bake();console.log('bake',T(),JSON.stringify({ms:bk.ms,N:bk.N,st:bk.st}));
  const lods=await p.waitForFunction(()=>{const Y=window.__dyb,S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return !Y.S2B.lod||!Y.DYB.w||(S&&S.lods)||null;},null,{timeout:120000,polling:300}).then(h=>h.jsonValue()).catch(()=>null);
  console.log('lighter copies',JSON.stringify(lods&&lods.st));
  await ev("TT.drawOnly(5);return 0;");await p.screenshot({path:out+'/phone_bay.png',timeout:900000});
  await p.tap('#sasDrive');await new Promise(r=>setTimeout(r,500));
  const info=c=>"const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));"+c+"return {state:Y.GAME.state,drawn:Math.round(S.drawn),shadow:Math.round(S.drawnSh),copy:S.lodK,px_mm:S.lodPx?+(S.lodPx*1000).toFixed(1):0,mph:+(Y.GAME.car.speed*2.237).toFixed(1)};";
  console.log('road, chase camera',JSON.stringify(await ev("Y.APP.cam=0;Y.CAM.cut=true;TT.place(300,1.9,0);TT.drive(4,{thr:1},12);TT.draw(4);"+info(""))));
  await p.screenshot({path:out+'/phone_road.png',timeout:900000});
  console.log('  with Only what can be seen off',JSON.stringify(await ev("Y.LOOK.carLean=0;TT.draw(3);"+info(""))));
  console.log('  and back on',JSON.stringify(await ev("Y.LOOK.carLean=1;TT.draw(3);"+info(""))));
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,10).join('\n  '):'no page errors');await b.close();})();
