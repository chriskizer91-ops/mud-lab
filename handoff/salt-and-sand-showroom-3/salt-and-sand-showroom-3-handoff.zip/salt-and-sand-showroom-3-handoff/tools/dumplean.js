/* writes a build's lean pieces (vtx + u32 idx) and info.json for shade. usage: node dumplean.js <key> <out> [kit.js] */
const fs=require('fs');const L=require('./kitrun2.js').load(process.argv[4]);const key=process.argv[2],out=process.argv[3];fs.mkdirSync(out,{recursive:true});
const t0=Date.now(),m=L.make(key);fs.writeFileSync(out+'/info.json',JSON.stringify(m.info));let nt=0;
for(const nm of Object.keys(m.pieces)){const D=m.pieces[nm];fs.writeFileSync(`${out}/${nm}.vtx`,Buffer.from(D.vtx));const i=new Uint32Array(D.idx);fs.writeFileSync(`${out}/${nm}.idx`,Buffer.from(i.buffer));nt+=D.nt*(/^(wheel|brake)$/.test(nm)&&!m.pieces[nm+'R']?4:1);}
console.log(key,'triangles',nt,JSON.stringify(m.info.tris),'ms',Date.now()-t0);
