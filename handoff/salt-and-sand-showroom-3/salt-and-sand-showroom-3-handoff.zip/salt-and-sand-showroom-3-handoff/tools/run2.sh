#!/bin/bash
# the last round on the page as it ships: physics against the page as sent (both SUVs), the JavaScript's timing, a phone's layout, then the pictures on the road
O=/home/claude/out/final; cd /home/claude/tools
for k in stock crawler; do
  node t_phys.js /home/claude/work/orig/salt-and-sand.html $k > $O/phys_orig_$k.log 2>&1
  node t_phys.js $O/page.html $k "s2bake=8" > $O/phys_new_$k.log 2>&1
done
node t_prof.js /home/claude/work/orig/salt-and-sand.html > $O/prof_orig.log 2>&1
node t_prof.js $O/page.html "s2bake=8" > $O/prof_new.log 2>&1
node t_phone.js $O/page.html $O/phone "s2bake=32" > $O/phone.log 2>&1
BAY=0 FR=7 CAMS="Chase,Far" MODES="plain,lean,lod" node t_final.js $O/page.html $O/stock6 stock > $O/stock6.log 2>&1
echo done > $O/run2.done
