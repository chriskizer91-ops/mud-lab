#!/bin/bash
O=/home/claude/out/final; cd /home/claude/tools
while [ ! -f $O/run2.done ]; do sleep 10; done
node t_wheel.js /home/claude/work/orig/salt-and-sand.html $O/crawler_orig crawler > $O/crawler_orig.log 2>&1
node t_wheel.js $O/page.html $O/crawler_new crawler "s2bake=96" > $O/crawler_new.log 2>&1
echo done > $O/run3.done
