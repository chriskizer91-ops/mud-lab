/* the Rock & Mud as the kit builds it: where the mud flaps are against the tyres, and what of the underside stands up
   through the cabin's floor behind the front seats */
const L=require('./kitrun.js').load(process.argv[2]||'/home/claude/build/kit2_built.js','/home/claude/build/make2_built.js');
const K=L.ctx.KIT;K.setHD(true);K.setAlt('2');K.keepEngine(true);const T=K.studioBuild('crawler',.25);K.setAlt('');K.keepEngine(false);
const H=K.hdk(),D=T.D,X=H.X,lk=T.b.look,R=lk.tyre.R;
console.log('L',D.L.toFixed(2),'uFa',D.uFa.toFixed(3),'uRa',D.uRa.toFixed(3),'arch',JSON.stringify(D.arch),'tyre R',R,'W',lk.tyre.W,'track/2',(lk.track/2).toFixed(3),'dy',H.dy,'cowl',D.G.cowl.toFixed(2),'rf',D.G.rf.toFixed(2));
console.log('flap stands',(D.arch.a+.04).toFixed(3),'m behind each axle; the tyre reaches',R,'m: the flap is',(R-(D.arch.a+.04)).toFixed(3),'m inside the tyre');
const xr=X(D.uRa);
const cells=new Map(),key=(x,z)=>Math.round(x/.05)+','+Math.round(z/.05);
/* the cabin's floor: the lowest upward-facing surface of the cabin part over each 5 cm cell */
const C=T.hd.cabin;for(let t=0;t<C.m.length/3;t++){const o=t*9;if(C.n[o+1]<.5)continue;for(let k=0;k<9;k+=3){const kk=key(C.p[o+k],C.p[o+k+2]),y=C.p[o+k+1],c=cells.get(kk);if(c===undefined||y<c)cells.set(kk,y);}}
const hit=[];const U=T.under;
for(let t=0;t<U.m.length/3;t++){const o=t*9;for(let k=0;k<9;k+=3){const x=U.p[o+k],y=U.p[o+k+1],z=U.p[o+k+2];if(x>xr+1.3||x<xr-1.1)continue;const f=cells.get(key(x,z));if(f!==undefined&&y>f+.015)hit.push([x,y,z,y-f,U.m[t*3]]);}}
console.log('corners of the underside above the cabin floor (rear half):',hit.length);
for(const s of [1,-1]){const h=hit.filter(q=>Math.sign(q[2])===s);if(!h.length)continue;const mm=i=>[Math.min(...h.map(q=>q[i])).toFixed(2),Math.max(...h.map(q=>q[i])).toFixed(2)];
  console.log(s>0?'right':'left','n',h.length,'x',mm(0),'(rear axle x',xr.toFixed(2)+')','y',mm(1),'|z|',[Math.min(...h.map(q=>Math.abs(q[2]))).toFixed(2),Math.max(...h.map(q=>Math.abs(q[2]))).toFixed(2)],'stands up to',Math.max(...h.map(q=>q[3])).toFixed(2),'m over the floor');
  /* by 10 cm bands of |z| */
  for(let a=0;a<1;a+=.1){const b=h.filter(q=>Math.abs(q[2])>=a&&Math.abs(q[2])<a+.1);if(b.length)console.log('   |z|',a.toFixed(1),'n',b.length,'x',Math.min(...b.map(q=>q[0])).toFixed(2),Math.max(...b.map(q=>q[0])).toFixed(2),'top y',Math.max(...b.map(q=>q[1])).toFixed(2),'over floor',Math.max(...b.map(q=>q[3])).toFixed(2));}}
