/* vis.c: which triangles of a car can be seen from outside it.
   Renders the opaque pieces (body, hood, liner, engine; no glass, no wheels) into a depth buffer from many viewpoints
   all round the car (orthographic and from two distances), and marks every triangle that shows: a pixel of its own
   in the picture, or any of seven points on it (corners, edge middles, centre) not behind what the depth buffer holds.
   Out: <out>.<piece>.vis  one byte per triangle: bit0 seen from above the horizon, bit1 seen from below it.
   usage: vis <dump-dir> <out-prefix> [res=1536] [ndir=256] [bias_m=0.003]   */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <omp.h>

typedef struct { const char*name; float*pos; int nt; unsigned char*vis; int occl; } Piece;
static float* loadf(const char*dir,const char*nm,const char*ext,long*n){
  char p[1024]; snprintf(p,sizeof p,"%s/%s.%s.f32",dir,nm,ext); FILE*f=fopen(p,"rb"); if(!f){*n=0;return NULL;}
  fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET); float*d=malloc(sz); if(fread(d,1,sz,f)!=(size_t)sz){} fclose(f); *n=sz/4; return d; }

typedef struct { double r[3],u[3],f[3],eye[3]; int persp; double scale; /* ortho: px per metre; persp: focal px */ } View;
static void norm3(double*v){double l=sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);v[0]/=l;v[1]/=l;v[2]/=l;}
static void cross(const double*a,const double*b,double*c){c[0]=a[1]*b[2]-a[2]*b[1];c[1]=a[2]*b[0]-a[0]*b[2];c[2]=a[0]*b[1]-a[1]*b[0];}

/* project a point: returns 0 if behind the eye (persp). sx,sy in pixels, z = distance along the view (bigger = farther) */
static inline int proj(const View*V,int res,const float*p,double*sx,double*sy,double*sz){
  double d[3]={p[0]-V->eye[0],p[1]-V->eye[1],p[2]-V->eye[2]};
  double x=d[0]*V->r[0]+d[1]*V->r[1]+d[2]*V->r[2],y=d[0]*V->u[0]+d[1]*V->u[1]+d[2]*V->u[2],z=d[0]*V->f[0]+d[1]*V->f[1]+d[2]*V->f[2];
  if(V->persp){ if(z<0.05) return 0; *sx=res*0.5+x/z*V->scale; *sy=res*0.5-y/z*V->scale; *sz=z; }
  else { *sx=res*0.5+x*V->scale; *sy=res*0.5-y*V->scale; *sz=z; }
  return 1; }

int main(int argc,char**argv){
  if(argc<3){fprintf(stderr,"usage\n");return 1;}
  const char*dir=argv[1],*outp=argv[2]; int res=argc>3?atoi(argv[3]):1536, ndir=argc>4?atoi(argv[4]):256; double bias=argc>5?atof(argv[5]):0.003;
  const char* names[]={"body","hood","liner","engine"}; Piece P[4]; int np=0; long total=0;
  for(int i=0;i<4;i++){ long n; float*d=loadf(dir,names[i],"pos",&n); if(!d)continue; P[np].name=names[i];P[np].pos=d;P[np].nt=n/9;P[np].vis=calloc(n/9,1);P[np].occl=1; total+=n/9; np++; }
  /* bounds */
  double lo[3]={1e9,1e9,1e9},hi[3]={-1e9,-1e9,-1e9};
  for(int i=0;i<np;i++)for(long k=0;k<(long)P[i].nt*9;k++){int a=k%3;double v=P[i].pos[k];if(v<lo[a])lo[a]=v;if(v>hi[a])hi[a]=v;}
  double c[3]={(lo[0]+hi[0])/2,(lo[1]+hi[1])/2,(lo[2]+hi[2])/2}, rad=0.5*sqrt((hi[0]-lo[0])*(hi[0]-lo[0])+(hi[1]-lo[1])*(hi[1]-lo[1])+(hi[2]-lo[2])*(hi[2]-lo[2]));
  fprintf(stderr,"%ld triangles, centre %.2f %.2f %.2f, radius %.2f m, %d px, %d directions x 3\n",total,c[0],c[1],c[2],rad,res,ndir);
  /* views: for each direction, ortho + two distances */
  int nv=ndir*3; View*VW=malloc(sizeof(View)*nv); int*upper=malloc(sizeof(int)*nv);
  double dists[2]={rad+0.9,rad+4.0};
  for(int i=0;i<ndir;i++){
    double y=1-2*(i+0.5)/ndir, r=sqrt(1-y*y), ph=i*2.399963229728653; double d[3]={cos(ph)*r,y,sin(ph)*r};
    for(int k=0;k<3;k++){ View*V=&VW[i*3+k]; V->f[0]=-d[0];V->f[1]=-d[1];V->f[2]=-d[2];
      double up[3]={0,1,0}; if(fabs(d[1])>0.98){up[0]=1;up[1]=0;} cross(V->f,up,V->r); norm3(V->r); cross(V->r,V->f,V->u);
      double dist=k==0?rad*3:dists[k-1]; for(int a=0;a<3;a++)V->eye[a]=c[a]+d[a]*dist;
      V->persp=k>0; V->scale=k==0?(res*0.5/(rad*1.02)):(res*0.5/tan(asin(fmin(0.999,rad*1.02/dist))));
      upper[i*3+k]=d[1]>=-0.02; } }
  double t0=omp_get_wtime();
  #pragma omp parallel
  {
    float*zb=malloc(sizeof(float)*res*res); int*ib=malloc(sizeof(int)*res*res);
    unsigned char**loc=malloc(sizeof(void*)*np); for(int i=0;i<np;i++)loc[i]=calloc(P[i].nt,1);
    #pragma omp for schedule(dynamic,1)
    for(int v=0;v<nv;v++){ const View*V=&VW[v]; unsigned char bit=upper[v]?1:2;
      for(long k=0;k<(long)res*res;k++){zb[k]=FLT_MAX;ib[k]=-1;}
      int base=0;
      for(int pi=0;pi<np;pi++){ const float*pp=P[pi].pos;
        for(int t=0;t<P[pi].nt;t++){ double x[3],y[3],z[3]; int ok=1; for(int j=0;j<3;j++) if(!proj(V,res,pp+t*9+j*3,&x[j],&y[j],&z[j])){ok=0;break;} if(!ok)continue;
          double minx=fmin(x[0],fmin(x[1],x[2])),maxx=fmax(x[0],fmax(x[1],x[2])),miny=fmin(y[0],fmin(y[1],y[2])),maxy=fmax(y[0],fmax(y[1],y[2]));
          int x0=(int)floor(minx),x1=(int)ceil(maxx),y0=(int)floor(miny),y1=(int)ceil(maxy); if(x0<0)x0=0;if(y0<0)y0=0;if(x1>res-1)x1=res-1;if(y1>res-1)y1=res-1; if(x0>x1||y0>y1)continue;
          double a=(x[1]-x[0])*(y[2]-y[0])-(x[2]-x[0])*(y[1]-y[0]); if(fabs(a)<1e-12)continue; double ia=1.0/a;
          for(int py=y0;py<=y1;py++){ double cy=py+0.5; for(int px=x0;px<=x1;px++){ double cx=px+0.5;
              double w0=((x[1]-cx)*(y[2]-cy)-(x[2]-cx)*(y[1]-cy))*ia, w1=((x[2]-cx)*(y[0]-cy)-(x[0]-cx)*(y[2]-cy))*ia, w2=1-w0-w1;
              if(w0<0||w1<0||w2<0)continue; float zz=(float)(w0*z[0]+w1*z[1]+w2*z[2]); long o=(long)py*res+px; if(zz<zb[o]){zb[o]=zz;ib[o]=base+t;} } } }
        base+=P[pi].nt; }
      /* a pixel of its own */
      { int b1=0; long off[5]; off[0]=0; for(int pi=0;pi<np;pi++)off[pi+1]=off[pi]+P[pi].nt; (void)b1;
        for(long k=0;k<(long)res*res;k++){ int id=ib[k]; if(id<0)continue; int pi=0; while(id>=off[pi+1])pi++; loc[pi][id-off[pi]]|=bit; } }
      /* seven points on it, against the depth */
      for(int pi=0;pi<np;pi++){ const float*pp=P[pi].pos;
        for(int t=0;t<P[pi].nt;t++){ if(loc[pi][t]&bit)continue; const float*q=pp+t*9; float s[7][3];
          for(int a=0;a<3;a++){ s[0][a]=q[a];s[1][a]=q[3+a];s[2][a]=q[6+a]; s[3][a]=(q[a]+q[3+a])*.5f;s[4][a]=(q[3+a]+q[6+a])*.5f;s[5][a]=(q[6+a]+q[a])*.5f; s[6][a]=(q[a]+q[3+a]+q[6+a])/3.f; }
          for(int j=0;j<7;j++){ double sx,sy,sz; if(!proj(V,res,s[j],&sx,&sy,&sz))continue; int px=(int)floor(sx),py=(int)floor(sy); if(px<0||py<0||px>=res||py>=res)continue;
            /* the nearest of the 3x3 pixels round it is what could hide it; visible if not behind the FARTHEST of them by more than the bias
               (generous at silhouettes: a point at an edge is kept) */
            float zf=0; for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){ int qx=px+dx,qy=py+dy; if(qx<0||qy<0||qx>=res||qy>=res){zf=FLT_MAX;continue;} float zq=zb[(long)qy*res+qx]; if(zq>zf)zf=zq; }
            if(sz<=zf+bias){ loc[pi][t]|=bit; break; } } } }
    }
    #pragma omp critical
    { for(int i=0;i<np;i++)for(int t=0;t<P[i].nt;t++)P[i].vis[t]|=loc[i][t]; }
    free(zb);free(ib);
  }
  fprintf(stderr,"%d views in %.1f s\n",nv,omp_get_wtime()-t0);
  long tv=0,tu=0,tl=0;
  for(int i=0;i<np;i++){ long a=0,u=0,l=0; for(int t=0;t<P[i].nt;t++){ if(P[i].vis[t])a++; if(P[i].vis[t]&1)u++; if(P[i].vis[t]==2)l++; }
    printf("%-7s %7d triangles: seen from outside %7ld (%.1f%%), from above the horizon %7ld (%.1f%%), only from below %7ld (%.1f%%)\n",P[i].name,P[i].nt,a,100.0*a/P[i].nt,u,100.0*u/P[i].nt,l,100.0*l/P[i].nt);
    tv+=a;tu+=u;tl+=l; char p[1024]; snprintf(p,sizeof p,"%s.%s.vis",outp,P[i].name); FILE*f=fopen(p,"wb"); fwrite(P[i].vis,1,P[i].nt,f); fclose(f); }
  printf("ALL     %7ld triangles: seen from outside %7ld (%.1f%%), from above %7ld (%.1f%%), only from below %7ld (%.1f%%)\n",total,tv,100.0*tv/total,tu,100.0*tu/total,tl,100.0*tl/total);
  return 0; }
