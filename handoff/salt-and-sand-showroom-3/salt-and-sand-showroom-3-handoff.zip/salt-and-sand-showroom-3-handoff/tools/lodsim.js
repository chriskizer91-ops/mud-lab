/* offline: the lean pieces of a build, the seen-from-above part of the body (vis.c's flags), thinned with the given
   settings; writes <out>/<piece>.vtx, .idx (full) and .l1.idx/.l2.idx.  usage: node lodsim.js <key> <visprefix|-> <out> [json settings] */
const fs=require('fs');const {MeshoptSimplifier:MS}=require('/home/claude/npm/node_modules/meshoptimizer');
const L=require('./kitrun2.js').load();
(async()=>{await MS.ready;const key=process.argv[2],vis=process.argv[3],out=process.argv[4],O=Object.assign({errs:[.003,.009],w:[4,4,4,1,1,1,1,4],flags:['ErrorAbsolute','Prune']},JSON.parse(process.argv[5]||'{}'));
  fs.mkdirSync(out,{recursive:true});const m=L.make(key);fs.writeFileSync(out+'/info.json',JSON.stringify(m.info));
  for(const nm of Object.keys(m.pieces)){const D=m.pieces[nm],nu=D.nu;let idx=new Uint32Array(D.idx);
    fs.writeFileSync(`${out}/${nm}.vtx`,Buffer.from(D.vtx));fs.writeFileSync(`${out}/${nm}.idx`,Buffer.from(idx.buffer));
    if(nm==='body'&&vis!=='-'){const f=fs.readFileSync(vis+'.body.vis');const u=[];for(let t=0;t<f.length;t++)if(f[t]&1)u.push(idx[t*3],idx[t*3+1],idx[t*3+2]);idx=new Uint32Array(u);fs.writeFileSync(`${out}/${nm}.u.idx`,Buffer.from(idx.buffer));}
    if(nm==='engine'||nm==='liner')continue;
    const pos=new Float32Array(D.vtx),i16=new Int16Array(D.vtx),att=new Float32Array(nu*8);
    for(let v=0;v<nu;v++){const o=v*14,a=v*8;att[a]=i16[o+6]/32767;att[a+1]=i16[o+7]/32767;att[a+2]=i16[o+8]/32767;att[a+3]=i16[o+10]/32767;att[a+4]=i16[o+11]/32767;att[a+5]=i16[o+12]/32767;att[a+6]=i16[o+13]/32767;att[a+7]=i16[o+9];}
    let cur=idx;const n0=idx.length/3,res=[];
    O.errs.forEach((e,k)=>{const t0=Date.now();const r=MS.simplifyWithAttributes(cur,pos,7,att,8,O.w,null,0,e,O.flags)[0];fs.writeFileSync(`${out}/${nm}.l${k+1}.idx`,Buffer.from(r.buffer,r.byteOffset,r.byteLength));res.push(r.length/3+' ('+(Date.now()-t0)+' ms)');cur=r;});
    console.log(key,nm.padEnd(6),n0,'->',res.join(' -> '));}
})();
