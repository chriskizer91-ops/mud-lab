/* the bay, washed: a wheel close up and a three-quarter view, for a build. usage: node t_wheel.js <page> <outdir> <key> [query] */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3],key=process.argv[4]||'crawler',query=process.argv[5]||'';require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,errs,T,pick,bake}=await H.boot(page,{W:1280,H:720,Q:'medium',query});
  if(key!=='stock')await pick(key);
  console.log('booted',T(),JSON.stringify(await ev('return TT.s2()')));
  const bk=await bake();console.log('bake',T(),JSON.stringify(bk&&bk.st||bk));
  const N=+(process.env.FR||7);const R=key==='crawler'?.47:.378;
  const shot=async(name,setup)=>{await ev("Y.GAME.dirt=0;Y.SHOW.hood=false;Y.SHOW.hoodA=0;"+setup+"TT.drawOnly(3);if(Y.R){Y.R.resetTAA=true;}for(let i=0;i<arg;i++)Y.render(0);return 0;",N);await p.screenshot({path:`${out}/${name}.png`,timeout:900000});console.log(name,T());};
  await shot('wheel',`TT.cam({th:-82,ph:3,d:${key==='crawler'?2.3:2.0},ty:${R},ox:1.5,oy:0,oz:.9});`);
  await shot('front34',"TT.view('front34');");
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,8).join('\n  '):'no page errors');await b.close();})();
