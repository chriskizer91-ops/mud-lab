/* where the JavaScript's time goes in a frame (the parts that don't touch the graphics card are true numbers even in a
   test browser): the physics' steps, and the frame's sections as the game's own overlay times them; and how much memory
   a frame leaves behind for the garbage collector. usage: node t_prof.js <page> [query] */
const H=require('./base.js');
(async()=>{const page=process.argv[2],query=process.argv[3]||'';
  const {b,p,ev,errs,T,bake}=await H.boot(page,{W:960,H:540,Q:'mobile',query});
  await bake();
  await ev("document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;TT.place(300,1.9,0);TT.drive(3,{thr:1},0);return 0;");
  /* the physics alone: 1200 steps at speed */
  const phys=await ev("Y.setTestInput({steer:0,thr:1,brk:0,hb:0,nos:false});if(window.gc)gc();const m0=performance.memory?performance.memory.usedJSHeapSize:0,t0=performance.now();for(let i=0;i<1200;i++){Y.APP.t+=1/60;Y.step(1/60);}const t1=performance.now();return {ms_per_step:+((t1-t0)/1200).toFixed(3),kb_per_step:performance.memory?+((performance.memory.usedJSHeapSize-m0)/1200/1024).toFixed(2):null,mph:+(Y.GAME.car.speed*2.237).toFixed(1)};");
  console.log('physics',JSON.stringify(phys));
  /* on the sand, where the dust flies */
  const sand=await ev("TT.place(420,170,0);TT.drive(1,{thr:0},0);Y.setTestInput({steer:.15,thr:1,brk:0,hb:0,nos:false});const t0=performance.now();for(let i=0;i<600;i++){Y.APP.t+=1/60;Y.step(1/60);}return {ms_per_step:+((performance.now()-t0)/600).toFixed(3),mph:+(Y.GAME.car.speed*2.237).toFixed(1)};");
  console.log('physics on sand',JSON.stringify(sand));
  /* whole frames: the sections the game times itself (HUD = drawing the dials in JavaScript and sending them up) */
  if(await ev("return !!Y.PS;")){
    const fr=await ev("const n=24;const acc={};const N=['PHYS','WORLD','SHADOW','PROBE','SCENE','POST','HUD','SOUND','TREES','SEND','AI'];if(window.gc)gc();const m0=performance.memory.usedJSHeapSize;for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);Y.PS.cur.fill(0);Y.render(1/60);for(let k=0;k<N.length;k++)acc[N[k]]=(acc[N[k]]||0)+Y.PS.cur[k];}const m1=performance.memory.usedJSHeapSize;for(const k in acc)acc[k]=+(acc[k]/n).toFixed(2);acc.kb_per_frame=+((m1-m0)/n/1024).toFixed(1);return acc;");
    console.log('a frame, by section (ms)',JSON.stringify(fr));}
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,8).join('\n  '):'no page errors');await b.close();})();
