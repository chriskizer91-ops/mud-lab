/* as kitrun.js, with the build folder's kit and make (the lean pieces) */
const K=require('./kitrun.js');exports.load=(kit='/home/claude/build/src/kit.js',mk='/home/claude/build/src/s2make.js')=>K.load(kit,mk);
if(require.main===module){const L=exports.load();for(const key of (process.argv[2]||'stock').split(',')){const t0=Date.now();const m=L.make(key);const t=Date.now()-t0;
  let vb=0,ib=0,pr=0,nv=0,nt=0;for(const [n,d] of Object.entries(m.pieces)){const mult=/^(wheel|brake)$/.test(n)&&!m.pieces[n+'R']?4:/^(wheel|brake)R?$/.test(n)?2:1;vb+=d.vtx.byteLength;ib+=d.idx.byteLength;pr+=d.probeT?d.probeT.length:0;nv+=d.nu*mult;nt+=d.nt*mult;
    if(process.argv[3])console.log(' ',n,'nu',d.nu,'nt',d.nt,'probes',d.probeT?d.probeT.length:0,'idx',d.idx.constructor.name);}
  console.log(key,'ms',t,'(kit',m.info.ms+')','tris',nt,'verts drawn',nv,'MB vtx',(vb/1048576).toFixed(1),'idx',(ib/1048576).toFixed(1),'probes',pr);}}
