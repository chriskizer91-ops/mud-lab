/* the Showroom, as pictures: the bay, then the void black and white, a few views.
   usage: node t_void.js <page> <outdir> [key] [views]   env W H Q BAKE */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3],key=process.argv[4]||'stock';require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,errs,T,pick,bake}=await H.boot(page,{W:+(process.env.W||1280),H:+(process.env.H||720),Q:process.env.Q||'medium',query:'s2bake='+(process.env.BAKE||24)});
  if(key!=='stock')await pick(key);
  console.log('booted',T(),JSON.stringify(await ev('return TT.s2()')));
  const bk=await bake();console.log('bake',T(),JSON.stringify(bk&&bk.st));
  await ev("Y.GAME.dirt=0;Y.SHOW.hood=false;Y.SHOW.hoodA=0;Y.SHOW.spin=false;Y.showMode&&0;return 0;");
  const N=+(process.env.FR||10);
  const PIN="Y.R.frameN=4000;Y.R.resetTAA=true;Y.R.probeFilled=0;Y.R.probeFace=0;";
  const VIEWS={front34:"TT.view('front34');",rear34:"TT.view('rear34');",side:"TT.view('side');",low:"TT.view('low');",
    wheel:"TT.cam({th:-78,ph:4,d:2.0,ty:.5,ox:1.5,oy:0,oz:.9});",rear:"TT.cam({th:172,ph:6,d:3.2,ty:.95});",face:"TT.cam({th:-12,ph:5,d:3.3,ty:.85});",top:"TT.view('top');",rear2:"TT.cam({th:168,ph:7,d:4.4,ty:.95});",door:"TT.cam({th:90,ph:3,d:2.4,ty:.75,ox:.75});",wheel2:"TT.cam({th:90,ph:2,d:1.5,ty:.42,ox:1.42});",rw:"TT.cam({th:-152,ph:6,d:3.0,ty:.5,ox:-1.36,oy:0,oz:.87});",rw2:"TT.cam({th:-178,ph:8,d:3.4,ty:.55,ox:-1.36,oy:0,oz:0});",snork:"TT.cam({th:-58,ph:14,d:3.2,ty:1.25,ox:.7,oy:0,oz:.6});",cabin:"TT.cam({th:-125,ph:24,d:3.0,ty:1.25,ox:-.9,oy:0,oz:.2});",hoodup:"Y.SHOW.hood=true;Y.SHOW.hoodA=1;TT.cam({th:-42,ph:30,d:3.1,ty:1.3,ox:1.5,oy:0,oz:.3});",left34:"TT.cam({th:128,ph:10,d:5.6,ty:1.0});"};
  const shots=(process.argv[5]||'bay:dark:front34,void:dark:front34,void:light:front34,void:dark:rear34,void:light:low').split(',');
  for(const sh of shots){const [mode,stage,view]=sh.split(':');
    const r=await ev("Y.SHOW.stage=arg[1];Y.SHOW.void=arg[0]==='void'&&Y.showCanVoid();"+VIEWS[view]+"TT.drawOnly(3);"+
      "if(Y.SHOW.void&&arg[1]==='light'){const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));for(let i=0;i<400&&S&&!S.floor;i++)Y.render(0);}"+PIN+"for(let i=0;i<arg[2];i++)Y.render(0);"+
      "const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return {studio:Y.showStg().id,tris:Math.round(Y.APP.tris),floor:S&&S.floor?{tris:S.floor.tris,max:S.floor.max,none:S.floor.none}:null};",[mode,stage,N]);
    await p.screenshot({path:`${out}/${key}_${mode}_${stage}_${view}.png`,timeout:900000});console.log(sh.padEnd(22),JSON.stringify(r),T());}
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,14).join('\n  '):'no page errors');await b.close();})().catch(e=>{console.error('FAILED',e.message.slice(0,800));process.exit(1);});
