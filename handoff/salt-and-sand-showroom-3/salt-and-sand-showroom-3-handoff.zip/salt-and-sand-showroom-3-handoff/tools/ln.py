#!/usr/bin/env python3
"""ln.py <file> <from> <to> [width=420]: those lines, each cut to width."""
import sys
f,a,b=sys.argv[1],int(sys.argv[2]),int(sys.argv[3]);w=int(sys.argv[4]) if len(sys.argv)>4 else 420
for i,l in enumerate(open(f,encoding='utf-8').read().split('\n')[a-1:b],a):
    print(f'{i}: {l[:w]}'+(f' …[{len(l)}]' if len(l)>w else ''))
