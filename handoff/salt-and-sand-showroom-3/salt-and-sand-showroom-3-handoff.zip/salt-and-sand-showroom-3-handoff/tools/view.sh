#!/bin/bash
# view.sh <dir> <out.png> W H ex ey ez tx ty tz fov [hoodopen]: every piece of a dumped build, full detail
d=$1; o=$2; shift 2; S=/home/claude/tools/shade
read fx wb R tw < <(python3 -I -c "import json;i=json.load(open('$d/info.json'));print(i['fx'],i['wb'],i['R'],i['tw'])")
rx=$(python3 -I -c "print($fx-$wb)")
P="$d/body.vtx $d/body.idx $d/bodyG.vtx $d/bodyG.idx $d/hood.vtx $d/hood.idx $d/engine.vtx $d/engine.idx"
for z in "$fx $tw 1" "$fx -$tw -1" "$rx $tw 1" "$rx -$tw -1"; do set -- "$@"; read x zz s <<< "$z"; P="$P $d/wheel.vtx $d/wheel.idx $x $R $zz $s $d/brake.vtx $d/brake.idx $x $R $zz $s"; done
$S /tmp/view.ppm "$@" $P 2>/dev/null; python3 -I -c "from PIL import Image;Image.open('/tmp/view.ppm').save('$o')"
