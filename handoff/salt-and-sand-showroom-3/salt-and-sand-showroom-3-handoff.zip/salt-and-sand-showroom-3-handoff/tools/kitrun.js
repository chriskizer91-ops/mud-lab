/* Runs the Studio kit in Node and returns the pieces for a build key, as the page's worker does. */
const fs=require('fs'),vm=require('vm');
exports.load=function(kitPath='/home/claude/work/kit/kit.js',makePath='/home/claude/work/kit/make.js'){
  const kit=fs.readFileSync(kitPath,'utf8'),mk=fs.readFileSync(makePath,'utf8');
  const ctx={console,performance:{now:()=>Number(process.hrtime.bigint())/1e6},Math,Float32Array,Uint8Array,Uint16Array,Uint32Array,Int8Array,Int16Array,Int32Array,Float64Array,Map,Set,Object,Array,JSON,Number,String,Boolean,Date,Error,TypeError,RangeError,Symbol,Infinity,NaN,isFinite,isNaN,parseInt,parseFloat,ArrayBuffer,DataView,Promise,setTimeout};
  ctx.self=ctx;ctx.window=ctx;ctx.globalThis=ctx;
  vm.createContext(ctx);
  vm.runInContext(kit+'\n;\n'+mk+'\n;self.__s2Make=s2Make;',ctx,{filename:'kit.js'});
  return {ctx,make:k=>ctx.__s2Make(ctx.KIT,k).msg};
};
if(require.main===module){const K=exports.load(process.argv[3],process.argv[4]);const key=process.argv[2]||'stock';const t0=Date.now();const m=K.make(key);
  console.log(key,'built in',Date.now()-t0,'ms',JSON.stringify(m.info.tris));
  let tot=0,bytes=0;for(const [n,d] of Object.entries(m.pieces)){tot+=d.pos.length/9;bytes+=d.pos.byteLength+d.nrm.byteLength+d.col.byteLength+d.mat.byteLength;}
  console.log('tris (one of each piece)',tot,'MB',(bytes/1048576).toFixed(1));
  console.log(JSON.stringify(m.info,null,0).slice(0,800));}
