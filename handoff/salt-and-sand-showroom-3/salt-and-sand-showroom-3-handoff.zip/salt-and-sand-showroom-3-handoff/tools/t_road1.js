/* one road picture and the page's errors: node t_road1.js <page> <out.png> [key] */
const H=require('./base.js');
(async()=>{const {b,p,ev,errs,T,pick}=await H.boot(process.argv[2],{W:960,H:540,Q:'medium',query:'s2bake=0'});const key=process.argv[4]||'crawler';
  if(key!=='stock')await pick(key);
  await ev("document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;return 0;");
  const r=await ev("TT.place(300,1.9,0);TT.drive(1,{thr:0},0);TT.drive(3,{thr:1},0);for(let i=0;i<8;i++)Y.render(0);return {glassOn:Y.s2GlassOn(),left:Y.S2G.left,tris:Math.round(Y.APP.tris)};");
  await p.screenshot({path:process.argv[3],timeout:900000});console.log('road',T(),JSON.stringify(r));
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,10).join('\n  '):'no page errors');await b.close();})().catch(e=>{console.error('FAILED',e.message.slice(0,600));process.exit(1);});
