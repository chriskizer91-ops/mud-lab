#!/usr/bin/env python3
"""gx.py <file> <regex> [width=160] [max=40]: matches with a window of text round each (the game's lines are long)."""
import sys,re
f,pat=sys.argv[1],sys.argv[2];w=int(sys.argv[3]) if len(sys.argv)>3 else 160;mx=int(sys.argv[4]) if len(sys.argv)>4 else 40
s=open(f,encoding='utf-8').read();n=0
skip=('const S2KIT_SRC=','const S2MAKE_SRC=','const S2OPT_SRC=')
for m in re.finditer(pat,s):
    ls=s.rfind('\n',0,m.start())+1
    if s.startswith(skip,ls):continue
    ln=s.count('\n',0,m.start())+1
    a=max(ls,m.start()-w//3);b=min(len(s),m.end()+w);e=s.find('\n',m.end());b=min(b,e if e>0 else b)
    print(f'{ln}: {s[a:b]}');n+=1
    if n>=mx:print('...');break
