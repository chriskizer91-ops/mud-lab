/* each driving camera, parked: the same frozen moment drawn three ways from the same start (the frame counter, the TAA
   history and the exposure set back each time, so the pictures differ only where the triangles do):
   full = every triangle, as the page it was made from; lean = only what the view needs, no lighter copies; lod = as shipped.
   usage: node t_cull.js <page> <outdir> [query] [key]   env Q W H FR CAMS */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3],query=process.argv[4]||'',key=process.argv[5]||'stock';require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,shot,errs,T,pick,bake}=await H.boot(page,{W:+(process.env.W||1280),H:+(process.env.H||720),Q:process.env.Q||'medium',query});
  if(key!=='stock')await pick(key);
  const bk=await bake();console.log('bake',T(),JSON.stringify(bk));
  /* the lighter copies come back from the worker on their own */
  const lods=await p.waitForFunction(()=>{const Y=window.__dyb,S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return !Y.S2B.lod||(S&&S.lods)||null;},null,{timeout:120000,polling:300}).then(h=>h.jsonValue()).catch(()=>null);
  console.log('lighter copies',T(),JSON.stringify(lods));
  const N=+(process.env.FR||6);
  await ev("document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;TT.place(300,1.9,0);TT.drive(2,{thr:.6},0);TT.drive(3,{hb:1},0);TT.draw(8);return TT.info();").then(r=>console.log('parked',JSON.stringify(r)));
  const names=await ev("return Y.CAMS.slice();");
  const want=(process.env.CAMS||'Chase,Far,Wheel cam,Tracking car,Roadside,Drone follow,Low drone,Drone lead').split(',');
  const MODES={full:"Y.S2B.cull=false;Y.S2B.lod=false;",lean:"Y.S2B.cull=true;Y.S2B.lod=false;",lod:"Y.S2B.cull=true;Y.S2B.lod=true;"};
  const modes=(process.env.MODES||'full,lean,lod').split(',');
  for(const nm of want){const i=names.indexOf(nm);if(i<0){console.log('no camera',nm);continue;}const f=nm.replace(/\W+/g,'_').toLowerCase();
    await ev("Y.APP.cam=arg;Y.CAM.cut=true;Y.S2B.cull=true;Y.S2B.lod=true;TT.draw(4);return 0;",i);
    for(const md of modes){
      const r=await ev(MODES[md]+"const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));S.lodK=0;Y.R.frameN=4000;Y.R.resetTAA=true;Y.R.probeFilled=0;Y.CAM.cutFrame=true;for(let i=0;i<arg;i++)Y.render(0);return {drawn:Math.round(S.drawn),shadow:Math.round(S.drawnSh),copy:S.lodK,px_mm:S.lodPx?+(S.lodPx*1000).toFixed(1):0};",N);
      await p.screenshot({path:`${out}/${f}_${md}.png`,timeout:900000});console.log(nm.padEnd(13),md.padEnd(5),JSON.stringify(r),T());}
  }
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,14).join('\n  '):'no page errors');await b.close();})();
