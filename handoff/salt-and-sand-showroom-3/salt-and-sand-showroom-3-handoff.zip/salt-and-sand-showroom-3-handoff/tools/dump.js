/* Builds a Studio 2 car with the kit and writes each piece's raw arrays + info.json, for the C tools. usage: node dump.js <key> <outdir> [kit.js] */
const fs=require('fs');const key=process.argv[2],out=process.argv[3];fs.mkdirSync(out,{recursive:true});
const K=require('./kitrun.js').load(process.argv[4]);const m=K.make(key);
for(const [n,d] of Object.entries(m.pieces))for(const a of ['pos','nrm','col','mat'])fs.writeFileSync(`${out}/${n}.${a}.f32`,Buffer.from(d[a].buffer,d[a].byteOffset,d[a].byteLength));
fs.writeFileSync(out+'/info.json',JSON.stringify(m.info));console.log(key,JSON.stringify(m.info.tris));
