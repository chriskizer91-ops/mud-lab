const L=require('./kitrun.js').load(process.argv[2]||'/home/claude/build/kit4_built.js','/home/claude/build/make2_built.js');
const K=L.ctx.KIT;K.setHD(true);K.setAlt('2');K.keepEngine(true);const T=K.studioBuild('crawler',.25);
const H=K.hdk(),D=T.D,X=H.X,xr=X(D.uRa),U=T.under,C=T.hd.cabin;
/* the cabin's floor height: per 4 cm cell, every upward-facing cabin surface's height; the floor is taken as the highest one under 1.35 m */
const fl=new Map(),key=(x,z)=>Math.round(x/.04)+','+Math.round(z/.04);
for(let t=0;t<C.m.length/3;t++){const o=t*9;if(C.n[o+1]<.6)continue;const x=(C.p[o]+C.p[o+3]+C.p[o+6])/3,y=(C.p[o+1]+C.p[o+4]+C.p[o+7])/3,z=(C.p[o+2]+C.p[o+5]+C.p[o+8])/3;if(y>1.35)continue;const k=key(x,z),c=fl.get(k);if(c===undefined||y>c)fl.set(k,y);}
const out=[];for(let i=0;i<U.p.length;i+=3){const x=U.p[i],y=U.p[i+1],z=U.p[i+2];if(x<xr-.7||x>xr+.9)continue;const f=fl.get(key(x,z));if(f===undefined){if(y>1.0)out.push([x,y,z,9]);}else if(y>f+.02)out.push([x,y,z,y-f]);}
console.log('rear axle x',xr.toFixed(2),'underside corners above the cabin floor or where the cabin has no floor:',out.length);
for(const s of [1,-1]){const h=out.filter(q=>Math.sign(q[2])===s);for(let a=0;a<1;a+=.08){const b=h.filter(q=>Math.abs(q[2])>=a&&Math.abs(q[2])<a+.08);if(b.length>20)console.log(s>0?'R':'L','|z|',a.toFixed(2),'n',b.length,'x',Math.min(...b.map(q=>q[0])).toFixed(2),Math.max(...b.map(q=>q[0])).toFixed(2),'y',Math.min(...b.map(q=>q[1])).toFixed(2),Math.max(...b.map(q=>q[1])).toFixed(2),'nofloor',b.filter(q=>q[3]===9).length);}}
const f0=[];for(const z of [.2,.36,.44,.52,.6])for(const dx of [-.3,0,.3])f0.push('z'+z+' x'+(xr+dx).toFixed(2)+':'+(fl.get(key(xr+dx,z))||0).toFixed(2));console.log('floor heights',f0.join('  '));
