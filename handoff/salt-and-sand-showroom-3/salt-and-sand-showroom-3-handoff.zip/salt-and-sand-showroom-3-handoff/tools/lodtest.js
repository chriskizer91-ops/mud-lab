const {MeshoptSimplifier:MS}=require('/home/claude/npm/node_modules/meshoptimizer');
const L=require('./kitrun2.js').load();
(async()=>{await MS.ready;const key=process.argv[2]||'stock';const m=L.make(key);
  for(const nm of ['body','wheel','engine','brake','hood']){const D=m.pieces[nm];const pos=new Float32Array(D.vtx),i16=new Int16Array(D.vtx),nu=D.nu;
    const att=new Float32Array(nu*7);for(let v=0;v<nu;v++){const o=v*14;att[v*7]=i16[o+6]/32767;att[v*7+1]=i16[o+7]/32767;att[v*7+2]=i16[o+8]/32767;att[v*7+3]=i16[o+10]/32767;att[v*7+4]=i16[o+11]/32767;att[v*7+5]=i16[o+12]/32767;att[v*7+6]=i16[o+9];}
    const idx=D.idx instanceof Uint32Array?D.idx:new Uint32Array(D.idx);
    for(const [err,flags] of [[.0015,['ErrorAbsolute','Prune']],[.003,['ErrorAbsolute','Prune']],[.008,['ErrorAbsolute','Prune']],[.02,['ErrorAbsolute','Prune']],[.003,['ErrorAbsolute']],[.003,['ErrorAbsolute','Prune','Permissive']]]){
      const t0=Date.now();const [out,e]=MS.simplifyWithAttributes(idx,pos,7,att,7,[.6,.6,.6,1,1,1,4],null,0,err,flags);
      console.log(key,nm.padEnd(6),'err',err,flags.slice(1).join('+').padEnd(16),'tris',idx.length/3,'->',out.length/3,(100*out.length/idx.length).toFixed(1)+'%','ms',Date.now()-t0,'reached',e.toFixed(4));}
  }})();
