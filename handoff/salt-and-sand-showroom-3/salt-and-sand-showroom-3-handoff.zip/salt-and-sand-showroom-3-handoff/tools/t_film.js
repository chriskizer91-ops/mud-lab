/* the Film camera, driven: a scripted drive (stand, launch, cruise fast on the road, a slide, onto the dunes) with the
   Film camera on; prints each cut (time, what the car was doing, the shot) and saves a picture of some shots.
   usage: node t_film.js <page> <outdir> */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3];require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,errs,T}=await H.boot(page,{W:960,H:540,Q:'mobile',query:'s2bake=0'});
  console.log('booted',T());
  await ev("document.getElementById('sasDrive').click();Y.APP.cam=Y.CAMS.indexOf('Film');Y.CAM.cut=true;TT.place(300,1.9,0);return Y.CAMS.length;").then(r=>console.log('cameras',r));
  /* step the game and the camera (no picture) and log the cuts */
  await ev(`window.FL=[];window.runFilm=(sec,inp,label)=>{Y.setTestInput(Object.assign({steer:0,thr:0,brk:0,hb:0,nos:false},inp));const n=Math.round(sec*60);let last=Y.FILM.n;
    for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);const c=Y.camUpdate(1/60);Y.CAM.last=c;if(!c||!c.eye.every(Number.isFinite)||!c.fwd.every(Number.isFinite))throw new Error('bad camera '+Y.camMode());
      if(Y.FILM.n!==last){last=Y.FILM.n;FL.push([+(Y.APP.t).toFixed(1),label,Y.FILM.scene,Y.camMode(),Math.round(Y.GAME.car.speed*2.237)+' mph']);}}
    return TT.info();};return 0;`);
  const seg=async(sec,inp,label,pic)=>{const r=await ev("return runFilm(arg[0],arg[1],arg[2]);",[sec,inp,label]);
    if(pic&&process.env.PICS!=='0'){await ev("TT.draw(5);return 0;");const m=await ev("return Y.camMode();");await p.screenshot({path:`${out}/${pic}_${m.replace(/\W+/g,'_')}.png`,timeout:900000});console.log(' pic',pic,m,T());}
    console.log(label.padEnd(10),JSON.stringify({mph:r.mph,x:r.x,z:r.z,surf:r.surf.split(',')[0]}));};
  await seg(6,{hb:1},'stand','a_stand');
  await seg(5,{thr:1},'launch','b_launch');
  await seg(14,{thr:1},'fast','c_fast');
  await seg(10,{thr:1},'fast2','d_fast');
  await seg(1.2,{thr:1,steer:.9},'turn');await seg(2.5,{thr:1,steer:-.9,hb:1},'slide','e_slide');
  await seg(4,{thr:.6,steer:.35},'to dunes');await seg(14,{thr:.8},'dunes','f_dunes');await seg(10,{thr:.9,steer:.1},'dunes2','g_dunes');
  await seg(5,{brk:1},'stop');await seg(6,{hb:1},'stand2','h_stand');
  const L=await ev("return FL;");console.log('cuts:');for(const l of L)console.log('  ',l.join(' | '));
  const names=await ev("return Y.FILM.log;");const cnt={};for(const n of names)cnt[n]=(cnt[n]||0)+1;console.log('shots used',JSON.stringify(cnt));
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,10).join('\n  '):'no page errors');await b.close();})().catch(e=>{console.error('FAILED',e.message.slice(0,600));process.exit(1);});
