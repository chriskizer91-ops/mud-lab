/* how long a frame takes in the test browser (no graphics card: the computer's processor draws every triangle, so the
   time follows the work a graphics card is handed), on a phone-sized picture, chase camera, cruising. usage: node t_bench.js <page> [query] */
const H=require('./base.js');
(async()=>{const page=process.argv[2],query=process.argv[3]||'';
  const {b,p,ev,errs,T,bake}=await H.boot(page,{W:915,H:412,Q:'mobile',touch:true,query});
  await bake();
  await p.waitForFunction(()=>{const Y=window.__dyb;if(!Y.S2B)return true;const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return !Y.S2B.lod||!Y.DYB.w||(S&&S.lods)||null;},null,{timeout:120000,polling:300}).catch(()=>null);
  await ev("document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;TT.place(300,1.9,0);TT.drive(4,{thr:.5},6);TT.draw(6);return 0;");
  const time=async(name,pre)=>{const r=await ev(pre+"const gl=document.querySelector('canvas').getContext('webgl2');Y.setTestInput({steer:0,thr:.35,brk:0,hb:0,nos:false});const n=arg;for(let i=0;i<4;i++){Y.APP.t+=1/60;Y.step(1/60);Y.render(1/60);}const px=new Uint8Array(4),sync=()=>{gl.bindFramebuffer(gl.FRAMEBUFFER,null);gl.readPixels(0,0,1,1,gl.RGBA,gl.UNSIGNED_BYTE,px);};sync();const t0=performance.now();for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);Y.render(1/60);}sync();const ms=(performance.now()-t0)/n;const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return {ms:+ms.toFixed(0),tris:Y.APP.tris,car:S.drawn?Math.round(S.drawn):S.tris,shadow:S.drawnSh?Math.round(S.drawnSh):S.tris};",24);console.log(name.padEnd(34),JSON.stringify(r));};
  if(await ev("return !!Y.S2B;")){await time('as shipped',"Y.LOOK.carLean=1;");await time('every triangle (the switch off)',"Y.LOOK.carLean=0;");await time('as shipped, again',"Y.LOOK.carLean=1;");}
  else{await time('the page as sent',"");await time('the page as sent, again',"");}
  await b.close();})();
