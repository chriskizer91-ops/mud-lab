/* the Helicopter and Park orbit, as pictures: cruising at speed on the road, the Film camera held on one shot.
   usage: node t_heli.js <page> <outdir> */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3];require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,errs,T}=await H.boot(page,{W:960,H:540,Q:'medium',query:'s2bake=0'});
  await ev("document.getElementById('sasDrive').click();Y.APP.cam=Y.CAMS.indexOf('Film');Y.CAM.cut=true;TT.place(300,1.9,0);TT.drive(9,{thr:1},0);return TT.info();").then(r=>console.log('cruising',JSON.stringify(r)));
  const hold=async(shot,sec,name)=>{const r=await ev("Y.FILM.shot=arg[0];Y.FILM.t=0;Y.FILM.min=99;Y.FILM.max=99;Y.FILM.cutScene=Y.FILM.scene;Y.CAM.cut=true;Y.CAM.cutFrame=true;Y.setTestInput({steer:0,thr:arg[2],brk:0,hb:arg[2]?0:1,nos:false});const n=Math.round(arg[1]*60);for(let i=0;i<n;i++){Y.APP.t+=1/60;Y.step(1/60);if(i>n-14||i%5===0)Y.render(1/60);else{Y.CAM.last=Y.camUpdate(1/60);}}const c=Y.CAM.last,t=Y.GAME.car;return {shot:Y.camMode(),fov_deg:+(c.fov*57.3).toFixed(1),dist:+Math.hypot(c.eye[0]-t.p[0],c.eye[1]-t.p[1],c.eye[2]-t.p[2]).toFixed(0),up:+(c.eye[1]-t.p[1]).toFixed(1),mph:Math.round(t.speed*2.237)};",[shot,sec,name==='park'?0:.75]);
    await p.screenshot({path:`${out}/${name}.png`,timeout:900000});console.log(name,JSON.stringify(r),T());};
  await hold('Heli',4,'heli_start');await hold('Heli',5,'heli_mid');
  await ev("TT.place(1700,160,.6);TT.drive(6,{thr:.8},0);return TT.info();").then(r=>console.log('dunes',JSON.stringify(r)));
  await hold('Heli',3,'heli_dunes');
  await ev("TT.drive(4,{brk:1},0);return 0;");await hold('Park orbit',2,'park');
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,10).join('\n  '):'no page errors');await b.close();})().catch(e=>{console.error('FAILED',e.message.slice(0,600));process.exit(1);});
