const L=require('./kitrun.js').load('/home/claude/build/kit2_built.js','/home/claude/build/make2_built.js');
const K=L.ctx.KIT;K.setHD(true);K.setAlt('2');K.keepEngine(true);const T=K.studioBuild('crawler',.25);
const H=K.hdk(),D=T.D,X=H.X,G=D.G,sk=L.ctx.secKeys;
console.log('cowl',G.cowl,'rf',G.rf,'X(0)',X(0).toFixed(2),'X(cowl)',X(G.cowl).toFixed(2),'hood hinge',D.hood&&D.hood.hinge.map(v=>+v.toFixed(2)),'pillars',JSON.stringify(G.pillars&&G.pillars.slice(0,2)));
for(const u of [1.1,1.2,1.3,1.4,1.48,1.56,1.7,1.9,2.1,2.27,2.32]){const k=sk(D,u);console.log('u',u.toFixed(2),'x',X(u).toFixed(2),'belt yB',k.yB.toFixed(3),'P10 z,y',k.P[10].map(v=>+v.toFixed(3)),'sideZ(u,yB-.07)',H.sideZ(u,k.yB-.07).toFixed(3),'sideZ(u,yB)',H.sideZ(u,k.yB).toFixed(3),'nP',k.P.length,'topY',H.topY?H.topY(u,0).toFixed(3):'');}
