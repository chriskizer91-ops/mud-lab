const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3];
  const {b,p,ev,shot,errs,T}=await H.boot(page,{W:960,H:540,Q:process.env.Q||'mobile'});
  console.log('booted',T(),JSON.stringify(await ev('return TT.s2()')));
  await shot(out+'/bay.png',"return {state:Y.GAME.state,full:Y.SHOW.full};",4);
  await shot(out+'/road_start.png',"document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;return TT.drive(2,{thr:0});",8);
  await shot(out+'/road_fast.png',"return TT.drive(7,{thr:1});",6);
  console.log(errs.length?'page errors:\n  '+[...new Set(errs)].slice(0,14).join('\n  '):'no page errors');await b.close();})();
