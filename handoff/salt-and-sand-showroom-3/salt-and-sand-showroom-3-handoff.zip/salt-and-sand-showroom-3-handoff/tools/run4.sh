#!/bin/bash
O=/home/claude/out/final; cd /home/claude/tools
while [ ! -f $O/run3.done ]; do sleep 10; done
node t_bench.js /home/claude/work/orig/salt-and-sand.html > $O/bench_orig.log 2>&1
node t_bench.js $O/page.html "s2bake=48" > $O/bench_new.log 2>&1
echo done > $O/run4.done
