/* the lean page: boots, bakes, and shoots the bay and the road. usage: node t_v1.js <page> <outdir> [query] [key]  env Q W H FR */
const H=require('./base.js');
(async()=>{const page=process.argv[2],out=process.argv[3],query=process.argv[4]||'',key=process.argv[5]||'stock';require('fs').mkdirSync(out,{recursive:true});
  const {b,p,ev,shot,errs,T,pick,bake}=await H.boot(page,{W:+(process.env.W||960),H:+(process.env.H||540),Q:process.env.Q||'mobile',query});
  if(key!=='stock')await pick(key);
  console.log('booted',T(),JSON.stringify(await ev('return TT.s2()')));
  const bk=await bake();console.log('bake',T(),JSON.stringify(bk));
  const lods=await p.waitForFunction(()=>{const Y=window.__dyb,S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return !Y.S2B.lod||!Y.DYB.w||(S&&S.lods)||null;},null,{timeout:120000,polling:300}).then(h=>h.jsonValue()).catch(()=>null);
  console.log('lighter copies',T(),JSON.stringify(lods));
  const N=+(process.env.FR||6);
  await shot(out+'/bay.png',"Y.SHOW.hood=false;Y.SHOW.hoodA=0;TT.view('front34');return TT.s2();",N);
  await shot(out+'/bay_engine.png',"Y.SHOW.hood=true;Y.SHOW.hoodA=1;TT.view('bay');",N);
  await shot(out+'/bay_wheel.png',"Y.SHOW.hood=false;Y.SHOW.hoodA=0;TT.cam({th:-80,ph:3,d:1.9,ty:.5,ox:1.5,oy:0,oz:.9});",N);
  await shot(out+'/bay_wheel_left.png',"TT.cam({th:80,ph:3,d:1.9,ty:.5,ox:1.5,oy:0,oz:-.9});",N);
  await shot(out+'/road_start.png',"Y.SHOW.hood=false;Y.SHOW.hoodA=0;document.getElementById('sasDrive').click();Y.APP.cam=0;Y.CAM.cut=true;const r=TT.drive(2,{thr:0});const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return Object.assign(r,{drawn:Math.round(S.drawn),drawnSh:Math.round(S.drawnSh),copy:S.lodK});",N);
  await shot(out+'/road_fast.png',"const r=TT.drive(7,{thr:1});const S=Y.DYB.S2.get(Y.s2Key(Y.APP.bi));return Object.assign(r,{drawn:Math.round(S.drawn),drawnSh:Math.round(S.drawnSh),copy:S.lodK});",N);
  const e2=errs.filter(e=>!/ReadPixels/.test(e));console.log(e2.length?'page errors:\n  '+[...new Set(e2)].slice(0,14).join('\n  '):'no page errors');await b.close();})();
