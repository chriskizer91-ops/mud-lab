#!/usr/bin/env python3
"""imgdiff.py a.png b.png [out.png] [thr=16]: how many pixels differ by more than thr (0-255, any channel), where, and a picture of them"""
import sys
from PIL import Image
import numpy as np
a=np.asarray(Image.open(sys.argv[1]).convert('RGB')).astype(np.int16);b=np.asarray(Image.open(sys.argv[2]).convert('RGB')).astype(np.int16)
thr=int(sys.argv[4]) if len(sys.argv)>4 else 16
d=np.abs(a-b).max(axis=2);n=int((d>thr).sum())
ys,xs=np.nonzero(d>thr)
box=(int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())) if n else None
print(f'{sys.argv[1].split("/")[-1]} vs {sys.argv[2].split("/")[-1]}: mean {d.mean():.3f}  max {int(d.max())}  over {thr}: {n} px ({100*n/d.size:.3f}%)  box {box}')
if len(sys.argv)>3 and sys.argv[3]!='-':
    o=(a*0.35).astype(np.uint8);o[d>thr]=[255,40,40];Image.fromarray(o).save(sys.argv[3])
