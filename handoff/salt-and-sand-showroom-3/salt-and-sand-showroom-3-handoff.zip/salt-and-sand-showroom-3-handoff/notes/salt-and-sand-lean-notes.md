# Salt & Sand, lean: the review and what changed (10 Nov 2026)

*Goes with `claude/salt-flats-notes.md` (Salt & Sand's own notes) and `claude/salt-and-sand-lean-src.md` (its source).*

Christopher's ask: a performance review of the latest Salt & Sand, a driving model that looks more detailed without
costing more (he'd like it to cost less), and if possible a finer Dyno Bay model, with a demo on the Rock & Mud.
The page is `salt-and-sand-lean.html`, made from the page he sent that day by `patch.py`
(`claude/salt-and-sand-lean-src.md`). The page he sent is kept as it was.

### What the review found

- **The car is nearly the whole frame.** 808,095 of about 850,000 triangles, and it was drawn twice a frame (the
  picture, and the sun's near shadow map). The land is about 40,000 triangles and about 25 draw calls a frame (the
  "150 to 300 draws" in older notes was a running total across frames, not one frame).
- **Every corner was sent three times over.** The kit writes each triangle's three corners out in full (44 bytes
  each); most are shared with the triangles next door. SUV Stock: 2,424,285 corners a pass, 84 MB on the graphics
  card. Stored once each with the triangles as indices: 747,464 corners, 24 MB, the same triangles.
- **A fifth of the body can't be seen from outside**, and another fifth only from below. SUV Stock's body, hood
  shut: 342,527 triangles seen from above the car's horizon, 112,505 only from below, 103,893 never from outside.
  The engine: 415 / 8,902 / 19,811.
- **On the road there are several triangles to a pixel.** From the Far camera a pixel on the car is 11 mm across; the
  model has detail finer than 3 mm all over it.
- **No part of the car shaded another** except through the sun's shadow map: the sky's light and the bay's lamps
  reached the wheel arches, the cabin floor and the bottom of the engine bay as brightly as the roof.
- The JavaScript's own share is small and was left alone: the physics 0.07 ms a step; about 200 KB of throw-away
  memory a frame (the physics' step, the world's update, the map). The one thing worth a later look: the HUD's dials
  are drawn by JavaScript every frame (3.7 ms a frame in the test browser; F's overlay shows it as HUD on his
  devices). If that is over about 2 ms on the phone, drawing the dials only when their numbers change is next.

### What changed (all in `src/s2lean.js`, `src/s2make.js`; nothing in the physics, the sound, the cameras or the world)

1. **Each corner once.** The same triangles; a third of the corners to work through; 84 MB becomes 24 MB.
2. **The bake**, once per car on the graphics card, over the first seconds it is on screen (the line at the top says
   "shading 40%"). The car is looked at from 256 directions. For every corner it keeps how much of the sky that
   corner sees past the rest of the car, and whether it can be seen from outside at all.
3. **The car's own shade** (from the bake): the sky's light, the reflections and the shadowless lamps are dimmed
   where the car hides the sky from itself. In the bay too. The lamps' reflectors are left as they were.
4. **On the road, only what can be seen**: from a camera outside the car, the triangles nothing outside can see are
   not drawn, nor the ones only seen from lower than the camera is. The cockpit, the hood camera and the bay draw
   every triangle.
5. **Lighter copies farther off**, made by meshoptimizer's simplifier (MIT) in the worker: nothing moves more than
   3 mm (copy 1) or 9 mm (copy 2), the painted panels are not touched at all, and a copy is only drawn from where a
   pixel on the car is at least twice that size. The sun's shadow map always takes a copy.
6. Two switches in Settings, Dev, the look: **The car's own shade**, **Only what can be seen** (both on).

### The numbers (SUV Stock, test browser)

| | As sent | Lean |
|---|---|---|
| In the bay | 808,095 triangles, 2,424,285 corners, 84 MB | 818,199 triangles (the lettering), 747,464 corners, 24 MB |
| Road, Chase on a 720p picture | 808,095 + 808,095 for the shadow | 572,113 + 295,154 |
| Road, Chase on a phone-sized picture | 808,095 + 808,095 | 299,346 + 295,154 (copy 1) |
| Road, Far camera | 808,095 + 808,095 | 299,346 + 295,154 |

- The physics is the same to the last digit, both SUVs, six drives each (road flat out, braking, a turn onto the
  sand, the sand, a dune jump, the salt): SUV Stock 57.68 mph after 7 s on the road, 1.03 s in the air off the dune,
  on both pages.
- Pictures compared with every triangle drawn and with only what's needed, from the same frozen moment (Chase, Far,
  Wheel cam): the only pixels that differ are the frame-rate readout's.
- A frame in the test browser (a phone-sized picture, Chase, cruising): 1.66 s as sent, 1.15 s lean (30% less),
  and 1.65 s lean with Only what can be seen switched off. That computer has no graphics card and spends most of a
  frame lighting pixels, which nothing here changes, so it is only a pointer.
- The bake took 408 s in the test browser; on a real graphics card it should be a second or two on the laptop and a
  few on the phone. **Not measured on his devices: the frame rate.** That is his to read with F.
- If a device's bake answers nonsense (under a quarter of the body seen, or everything dark), it is left out and the
  car is drawn with every triangle and no shade.

### The finer tyres (a shared piece: the kit; `src/kit_tyres.js`)

- **Raised lettering on both SUVs' sidewalls**: REDLINE A/S and 245/65R17 111T on the Stock, REDLINE M/T,
  37X12.50R17 LT and MUD-TERRAIN on the Rock & Mud. The left wheels are their own copy (`wheelL`) so it reads the
  right way round on both sides.
- **The Rock & Mud's mud-terrain built again**: angled lugs with bevelled edges and a sipe, stone ejectors, side
  biters down the sidewall, a rim-protector rib. 34,490 triangles a wheel became 64,264; the car 790,531 became
  909,627 (in 26 MB, where the old one took 85).
- `?tyres=2` at the end of the address builds them as they were.

### My view on the Dyno Bay models (he asked)

The Studio 2 SUVs are already modelled about as far as geometry pays: the underside, the engine bay, the cabin, the
lamps' insides and the winch are all there. What they lacked was light that knows the shape (now baked) and the
small things a truck person looks for up close (the tyres, done here as a demo). Next in the same vein, if he wants
them: real gaps at the doors' shut lines, the brake hoses and ABS leads at each wheel, tread wear bars and a little
flash on the tyres, stitching on the seats. None of it costs anything on the road, because the copies drop it.

### Not done, or to check

- Ice & Snow and the Redtail builds are still made from the old page. `ice-and-snow-freeze.py` applies to the lean
  page as it is.
- The other eight cars get steps 1 to 5 as they are (they build and bake the same way); only the SUV Stock and the
  Rock & Mud were looked at closely.
- On the laptop: F's overlay names the graphics card. If it says Intel and not RTX 5060, Edge is on the wrong one
  (Windows Settings, System, Display, Graphics, Edge: High performance).
