# Salt & Sand, Film & Showroom, 2: the laptop's loading screen (10 Nov 2026)

*Follows `claude/salt-and-sand-showroom-notes.md`. The fix is `claude/salt-and-sand-showroom-patch3.py`, run on
`salt-and-sand-showroom.html` to make `salt-and-sand-showroom-2.html`.*

### What Christopher saw

On the MSI laptop (Windows, Edge) the Showroom page stood at **"Warming up the shaders 22 / 24"**, the Studio 2 line
read **"shading 0%"**, the fan ran and nothing else happened. On the Pixel 7a the same page opened and the Film
camera looked good.

### What it most likely is (not seen on his laptop: the test machine is Linux)

- A Windows browser turns every shader into the graphics driver's own language and builds it the first time it meets
  that exact text; the result is kept on disk, so later opens are quick. A phone doesn't work that way, which is why
  the phone opened.
- The lean page was the first in a long while to change the game's biggest shader (the lit one, in its two forms,
  `land` and `landProbe`): 43 changed lines in about 800, none heavy. Changed text means built from cold.
- The loader (`G.warmup`, the renderer's) waited 60 s for the builds, then stopped the whole page to wait for the
  rest. A stopped page with the count frozen at 22 / 24 looks like a hang. "Shading 0%" is only the bake waiting
  for the game to start.
- 22 of 24 means two programs were still building. The two forms of the lit shader are the likely pair, but the
  page did not say which, so this is not proved.

### What changed (patch3.py)

- The loader waits **without stopping the page**, up to 15 minutes, and after 8 s the loading line counts the
  seconds and **names what is still being built**, with a sentence saying the first time can take a few minutes.
- The bake's three small programs (`s2bkDepth`, `s2bkTally`, `s2bkOut`) are no longer waited for at the start. The
  bake begins once they are built (`s2BakeReady`), and is left out if they aren't after 30 s: the car is then drawn
  with every triangle and no shade, and the game runs.
- Shared piece: `G.warmup` is the renderer's (Shiftlight 3). Its callback now gets two more values (the names
  still waited for, the seconds); an old callback that ignores them works as before.

### Checked

- The fixed page loads, bakes the SUV Stock and opens the Showroom in the test browser (818,199 triangles in the
  bay, 891,403 in the Showroom, no page errors). The slow-build path itself can't be made to happen there.

### If it still doesn't get through on the laptop

- The line will name the shaders and the seconds. With the names in hand: cut that shader down for Windows, or open
  the game on the page's previous lit shader (which the laptop already has built) and switch to the new one when the
  driver has finished it.
