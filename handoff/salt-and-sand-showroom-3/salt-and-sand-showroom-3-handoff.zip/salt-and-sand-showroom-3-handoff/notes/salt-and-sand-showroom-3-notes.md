# Salt & Sand: Film & Showroom, round 3 (10 Nov 2026)

Page: `salt-and-sand-showroom-3.html`. Built from `salt-and-sand-showroom-2.html` by `patch4.py` (exact text swaps)
plus two new pieces, `src3/kit_fix.js` and `src3/glass.js`. Earlier pages are untouched.
Source in this project: `claude/salt-and-sand-showroom-patch4.py`, `claude/salt-and-sand-showroom-3-kit-fix.js`,
`claude/salt-and-sand-showroom-3-glass.js`.

Why: Christopher looked the Rock & Mud over in the bay on the laptop and found five things.

## What changed

| He said | Cause | Fix |
|---|---|---|
| "a panel through the middle of each back tire" | The mud flaps were sized for the Stock's tyres: 26 cm wide, hung on the body line, inboard of a 32 cm tyre that stands out past the body. | `cwFlaps2`: each flap hangs behind its own tyre, centred on it, 4 cm wider than the tyre, 10 cm behind the tread, down to 17 cm off the ground. All four flaps. |
| windows "kind of broken glass" | See-through was done by leaving out a share of the pixels (dots) and letting the picture's smoothing even them out. Standing still in the bay it never fully does. | In the bay and Showroom the glass is now truly blended over what is behind it (no dots). See "Glass" below. |
| snorkel does a "weird s curve", sits beside the pillar, ends in "an open pipe" | It stood 8 cm out to the side on brackets, curved round the mirror and stopped on the fender's side touching nothing. | `cwSnorkel2`: straight, lying on top of the passenger windscreen pillar, running on into the top of the fender behind the hood's corner through a flange. Under the hood the air cleaner's duct now runs to that spot. |
| suspension visible behind the rear seat; keep the nitrous bottle visible | The rear coilovers stand 14 cm up through the cargo floor, just inboard of the carpeted wheel houses (which are the Stock's). | `cwHouses`: each wheel house carried 22 cm further in as a carpeted tower over its coilover. The bottle lies 16 cm behind the left one, in the open as before. |
| can the doors and the back open? | Not built: the body is one shell with shut lines drawn on it. | Not in this round. See "Doors" below. |

## Glass (a shared piece: the renderer's lit shader)

- The lit shader gets a third build, `landGlass` (define `GLASS`): it keeps every pixel and returns colour times
  glass strength with the strength as alpha; its 2nd and 3rd outputs are zero, so what is behind is left alone.
- It is drawn from the renderer's own glass hook (`STUDIO.glass`), after everything solid. In that frame the solid
  pass skips the car's glass pieces (`bodyG`, `hoodG`).
- Blended glass has to be drawn far to near. The glass is one mesh, so it is drawn twice, cut by an upright plane
  through the cabin facing the camera (`uGSplit`, in the car's own frame): far half, then near half.
- The third build starts the first time the bay shows a Studio 2 car, in the background. The loader does not wait
  for it. Until it is ready, or if it will not build on a device, the old dotted glass is used.
- Bay and Showroom only. On the road the dotted see-through is unchanged.
- Dev panel switch: "Clear glass in the bay" (on by default). Off gives the old look.
- Found and fixed while testing: finishing the new build in the middle of the solid pass left the wrong program
  in use for one frame (WebGL warnings). The build is now taken up between passes.

## Shared pieces changed (per the project rule)

- Vehicle kit (`S2KIT_SRC`): Rock & Mud only. `cwSnorkel` -> `cwSnorkel2`, `cwFlaps` -> `cwFlaps2` + `cwHouses`,
  one duct path in the engine bay. The Stock SUV's model is not touched.
- Renderer / lit shader: the `GLASS` build above, `P_LANDG`, `landRebuild` drops it with the others, the loader's
  wait list leaves out `landGlass`.
- Physics, Digital Engine, sound, cameras: not touched.

## Checks

All on the test machine (headless Chrome, software renderer), on the final page.

- Same-drive physics, six drives each, Stock and Rock & Mud: every number identical to the original page
  (`phys_orig_*.log`). Stock after 7 s flat out: 57.68 mph, as before.
- Page errors: none (Stock: bay, white Showroom, bay again; Rock & Mud: physics run and one road picture).
- Triangles: Stock 818,199 (unchanged). Rock & Mud 913,491 (was 909,627: +3,864 for the new flaps, snorkel,
  towers). Showroom detail on top as before (Rock & Mud 991,673 in the black Showroom).
- Pictures from the real page: bay front, side, left rear quarter, cargo area, hood up; black Showroom rear;
  white Showroom front (Rock & Mud) and rear (Stock). Glass clear in all; flap behind the tyre; snorkel on the
  pillar; no springs behind the seat, bottle visible; duct meets the snorkel under the hood.
- Road: one picture after the bay. The car draws with the old dotted glass, as intended.
- Proof sheets: `pics3/glass-before-after.png`, `pics3/rock-and-mud-fixes.png`.
- The road picture was not compared pixel for pixel with showroom-2 this round (the road's drawing code is not
  changed: the same two shader builds, and the glass pass only runs in the bay).

## Not checked

- Nothing here was run on the real laptop or phone. All pictures are from the test machine's software renderer.
- How long the glass build takes on the laptop the first time (expect the dotted glass for a few seconds on the
  very first visit to the bay, then clear).
- Front flaps against the rock sliders at full steering lock.

## Doors and tailgate (asked, not built)

The body is one shell; door lines are only drawn on. To open them each door (skin, glass, handle, mirror, inner
trim) has to become its own hinged piece, and the parts a shut door hides (jambs, sills, pillar faces, the
tailgate opening) have to be modelled, because today there is nothing there. Plan offered: one SUV first, in two
steps. Step 1: split the doors and tailgate off and swing them from a Doors toggle and a Tailgate toggle beside
Hood. Step 2: jambs, door shells, hinges, tailgate struts. A toggle rather than tapping the door: simpler on a phone.
