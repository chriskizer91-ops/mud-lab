# Salt & Sand, Film & Showroom: what was added (10 Nov 2026)

*Goes with `claude/salt-flats-notes.md` (Salt & Sand's own notes), `claude/salt-and-sand-lean-notes.md` (the lean page this
is built on) and `claude/salt-and-sand-showroom-src.md` / `-src-2.md` (its source).*

Christopher's ask, the same afternoon as the lean page: one more camera that picks its own shots or tracks from a
distance like a drone (every existing camera kept); the Doppler effect toned down when the car flies past a camera
("the audio-engineer tuned version of a video of a car"); and a switch on the SUV Stock and the Rock & Mud that takes
them into a flat black or white void with nothing but the car, holding an upgraded model of each.

The page is `salt-and-sand-showroom.html`, made from `salt-and-sand-lean.html` by `patch2.py`. The lean page and the
page he first sent are kept as they were.

### 1. The Film camera (a 16th camera, after Chase in the list)

- The game already had a **Director** switch: it changes camera by the clock, at random. That is still there.
- **Film** is different: it reads what the car is doing and cuts to the shot a car film would use for it.
  Standing still: a slow walk round the car. Pulling away hard: wheel cam, a roadside camera, the tracking car.
  Sliding: shots that keep the whole car in view (and no cut while the slide is young). On the dunes: helicopter,
  low drone, following drone, chase, a long lens. Fast and straight: helicopter, tracking car, a roadside fly-past,
  the long lens far ahead, the drone looking back. In the air: the jump cam, then a new shot for the landing.
- Two shots of its own. **Helicopter**: a long lens 55 to 90 m off to one side and 9 to 25 m up, flying with the car
  and coming slowly round it from the front quarter to the rear quarter (or back), the car about a third of the
  picture's width; it climbs if a dune gets between. **Park orbit**: close and low round the standing car.
- Rules: every shot has a shortest and longest time; a fly-past ends when the car has gone by; never the same shot
  twice running, nor the one before it.
- A list of cameras saved before today gets Film switched on once; after that it stays as he sets it
  (Settings, Cameras).
- Checked by a scripted drive (stand, launch, flat out on the road, a handbrake slide, onto the dunes, stop):
  10 cuts in 78 s, each to a shot from the right list for what the car was doing (stand: Park orbit; launch at
  9 mph: Wheel cam; 41 mph: Helicopter; 91 mph: Chase; 108 mph: the long lens; the slide: Helicopter; dunes: Low
  drone). Pictures: `film-shots.png`.

### 2. The fly-past pitch, softer

- What it was: the sound engine's own listener already bends the pitch as the car's distance changes (6/10 of the
  real Doppler shift, on everything: engine, exhaust, tyres). On top of that the standing cameras (Cinematic,
  Roadside, Low drone, the jump cam) turned the engine's pitch by the whole real shift again. So close by, the
  engine swung about 1.6 times what a microphone would hear.
- Now the engine swings 0.8 of the real thing at every distance.

| Passing a roadside camera at | Before | Now | A real microphone |
|---|---|---|---|
| 60 mph | 4.3 semitones | 2.2 | 2.7 |
| 100 mph | 7.2 semitones | 3.6 | 4.5 |

- A switch in Settings, Dev, the look: **Softer fly-past sound** (on). Off is exactly as before.
- **Not checked by ear**: the test machine has no sound. The numbers are from the formula the page uses.
- The Digital Engine itself (the synth) was not touched: the change is in Salt & Sand's cameras (`flyPitch`).

### 3. The Showroom

- A **Showroom** button, first in the bay's Look bar, there only for the SUV Stock and the Rock & Mud.
  On: no walls, no turntable, no dyno. The bar's Dark bay / Light cyc picks black or white.
- **What the camera sees** is one flat colour. **What the paint reflects** is a photographer's rig that is never in
  the picture: black, a big soft box overhead and a strip light down each side; white, a bright room.
- **White**: the car stands on its own soft shadow. It is worked out once per car on the graphics card (how much of
  the room each point of the floor can't see past the car, 192 directions), a few seconds the first time.
  The corners' darkening is switched off in the voids so the colour really is flat.
- **Black**: no floor at all.
- **The showroom's detail** (pieces of their own, drawn only here, so the bay and the road cost what they did):
  - the tyres' small print, raised in the rubber: construction, load and pressure, treadwear grades, DOT code, a
    band of fine ribs round the bead, eight tread wear marks;
  - the rear plate embossed with a border: SALT 46 (Stock), MUD 37 (Rock & Mud);
  - the heated rear window: its lines across the glass and a bus bar down each side;
  - raised chrome lettering following the panels: REDLINE and 4.6 V8 (or ROCK & MUD) on the tailgate, 4X4 (or
    ROCK & MUD) low on each front door.

| In the showroom | Dyno Bay | Showroom |
|---|---|---|
| SUV Stock | 818,199 triangles | 891,403 (white: 16,842 more for the floor's shadow) |
| Rock & Mud | 909,627 triangles | 987,809 |

- Pictures: `showroom-stock.png`, `showroom-rock-and-mud.png`.
- The test pictures are grainy on the paint and dotted on the glass: they are 6 frames from a standing start on
  software graphics. The game's own smoothing builds the picture up over the frames that follow.

### What did not change

- The driving: the same six drives on the page he first sent and on this one, both SUVs, match to the last digit
  (SUV Stock 57.68 mph after 7 s on the road).
- The road's picture: the Chase and Far cameras drawn from the same frozen moment on the lean page and on this one.
  Chase: no pixel differs by more than 5 levels in 255 (the film grain). Far: 50 pixels, all in the frame-rate
  readout.

### Shared pieces changed (written down as the project map asks)

- **The kit (the vehicle models)**: `KIT.showDetail(key, T)` added, with `hdTextOn` (raised lettering on any
  surface), `hdTyreRibs`, `hdTyrePrint`, `hdHeatLines`, and two more letters in the stroke font (`&`, `^`). Nothing
  existing is altered; a page that never calls `showDetail` gets the cars as before.
- **The maker (`s2Make`)**: three more pieces may come back, `bodyX`, `wheelX`, `wheelXL`; their triangle counts
  are in `info.trisX`, apart from `info.tris`.
- **The renderer (Shiftlight 3)**: `studioEnv` knows studios 3 (black void) and 4 (white void); the lit shader
  paints material 21 as the void's white, darkened by the vertex colour, when the studio is 4; a frame's
  environment may carry `vig` (its own corner darkening).
- **The lean bake**: `bodyX` is shaded with the body's pieces, `wheelX` / `wheelXL` with the wheels.

### Not done, or to check

- By ear: the softer fly-past, on his devices.
- The Film camera over a long drive: only the scripted 78 s and a few held shots were run.
- The showroom's frame rate on the phone (72,000 to 78,000 more triangles than the bay, and no walls to draw).
- The showroom models are the Studio 2 cars plus fine detail, not new bodies. Next in the same vein: brake hoses
  and ABS leads, lettering on the calipers and the wheel caps, seat stitching, metal flake in the paint up close,
  and drawing the showroom at the screen's full sharpness.
- A close-up from inside the wheel arch stalled the test browser (software graphics); not seen on a real card.
